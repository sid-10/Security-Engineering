#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <openssl/aes.h>
#include <openssl/evp.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <unistd.h>
#include <openssl/hmac.h>

/**
 * Create a 256 bit key and IV using the supplied key_data. salt can be added for taste.
 * Fills in the encryption and decryption ctx objects and returns 0 on success
 **/
int aes_init(unsigned char *key_data, int key_data_len, unsigned char *salt, EVP_CIPHER_CTX *e_ctx, 
             EVP_CIPHER_CTX *d_ctx)
{
  int i, nrounds = 5;
  unsigned char key[32], iv[32];
  
  /*
   * Gen key & IV for AES 256 CBC mode. A SHA1 digest is used to hash the supplied key material.
   * nrounds is the number of times the we hash the material. More rounds are more secure but
   * slower.
   */
  i = EVP_BytesToKey(EVP_aes_256_cbc(), EVP_sha1(), salt, key_data, key_data_len, nrounds, key, iv);
  if (i != 32) {
    printf("Key size is %d bits - should be 256 bits\n", i);
    return -1;
  }

  EVP_CIPHER_CTX_init(e_ctx);
  EVP_EncryptInit_ex(e_ctx, EVP_aes_256_cbc(), NULL, key, iv);
  EVP_CIPHER_CTX_init(d_ctx);
  EVP_DecryptInit_ex(d_ctx, EVP_aes_256_cbc(), NULL, key, iv);

  return 0;
}

/*
 * Encrypt *len bytes of data
 * All data going in & out is considered binary (unsigned char[])
 */
unsigned char *aes_encrypt(EVP_CIPHER_CTX *e, unsigned char *plaintext, int *len)
{
  /* max ciphertext len for a n bytes of plaintext is n + AES_BLOCK_SIZE -1 bytes */
  int c_len = *len + AES_BLOCK_SIZE, f_len = 0;
  unsigned char *ciphertext = malloc(c_len);

  /* allows reusing of 'e' for multiple encryption cycles */
  EVP_EncryptInit_ex(e, NULL, NULL, NULL, NULL);

  /* update ciphertext, c_len is filled with the length of ciphertext generated,
    *len is the size of plaintext in bytes */
  EVP_EncryptUpdate(e, ciphertext, &c_len, plaintext, *len);

  /* update ciphertext with the final remaining bytes */
  EVP_EncryptFinal_ex(e, ciphertext+c_len, &f_len);

  *len = c_len + f_len;
  return ciphertext;
}

/*
 * Decrypt *len bytes of ciphertext
 */
unsigned char *aes_decrypt(EVP_CIPHER_CTX *e, unsigned char *ciphertext, int *len)
{
  /* plaintext will always be equal to or lesser than length of ciphertext*/
  int p_len = *len, f_len = 0;
  unsigned char *plaintext = malloc(p_len);
  
  EVP_DecryptInit_ex(e, NULL, NULL, NULL, NULL);
  EVP_DecryptUpdate(e, plaintext, &p_len, ciphertext, *len);
  EVP_DecryptFinal_ex(e, plaintext+p_len, &f_len);

  *len = p_len + f_len;
  return plaintext;
}





uid_t name_to_uid(char const *name)
{
  if (!name)
    return -1;
  long const buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
    return -1;
  // requires c99
  char buf[buflen];
  struct passwd pwbuf, *pwbufp;
  if (0 != getpwnam_r(name, &pwbuf, buf, buflen, &pwbufp)
      || !pwbufp)
    return -1;
  return pwbufp->pw_uid;
}
char const * uid_to_name(uid_t uid)
{
  if (uid==0)
    return "root";
  if (!uid)
    return NULL;
  long const buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
    return NULL;
  // requires c99
  char buf[buflen];
  struct passwd pwbuf, *pwbufp;
  if (0 != getpwuid_r(uid, &pwbuf, buf, buflen, &pwbufp)
      || !pwbufp)
    return NULL;
  return pwbufp->pw_name;
}

uid_t name_to_gid(char const *name)
{
  if (!name)
    return -1;
  long const buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
    return -1;
  // requires c99
  char buf[buflen];
  struct passwd pwbuf, *pwbufp;
  if (0 != getpwnam_r(name, &pwbuf, buf, buflen, &pwbufp)
      || !pwbufp)
    return -1;
  return pwbufp->pw_gid;
}

char *global_perm_file;
char *global_hmac_file;


int readfromFile(char *filepath)
{
  FILE *fp;
  fp = fopen(filepath, "r");        // ENTER TEXT TO FILE
    if (fp == NULL)
  {
      printf("Error opening file in function!\n");
      exit(1);
  }




  int PassphraseFound = 0;
  FILE *f = fopen(global_perm_file, "r");
  if (f == NULL)
  {
      printf("Error opening file!\n");
       exit(1);
  }
        
  printf("R1d\n");

  char * line = NULL;
  ssize_t read; 
  size_t len = 0;
  
  EVP_CIPHER_CTX en, de;
  unsigned int salt[] = {12345, 54321};
  unsigned char *key_data;
  int key_data_len;
  
  printf("\nEnter Passphrase : ");
  char *temp_string1 = (char *)malloc(sizeof(char)*200+1);
  char *temp_string1match = (char *)malloc(sizeof(char)*200+1);
  scanf("%s",temp_string1);
  

  while((read = getline(&line, &len, f)) != -1)
  { 
    printf("R2d\n");
    //printf("\nline : %s", line);
    if(strstr(line, "Passphrase") != NULL)   //Perm File contains user entry
    {
      char s[2]=":";            
      char *token1;
      char *token2;
      token1 = strtok(line, s);
      token2 = strtok(NULL, s);
      strcpy(temp_string1match, token2);
      PassphraseFound = 1;

    }

  }

  if(PassphraseFound == 0)
  {
    printf("Unable to Retrieve File Passphrase. Exiting !\n");
    return 0;
  }
  char * testerString = malloc(sizeof("a")*1024+1);
  strcpy(testerString,temp_string1);
  strcat(testerString,"\n");
  printf("Entered : %d:%s\n", strlen(temp_string1),temp_string1);
  printf("Actual : %d:%s\n", strlen(temp_string1match),temp_string1match);
  if(strcmp(testerString,temp_string1match)!=0)
  {
    printf("Invalid Passphrase Entered. Exiting !\n");
    return 0;

  }  
  
  printf("\n\nRead Data :\n");    
  char data_line[1024];
  fgets(data_line, sizeof(data_line), fp); 
  
  

  key_data = (unsigned char *)temp_string1;
  //key_data = (unsigned char *)argv[1];
  key_data_len = strlen(key_data);
  printf("Key len :::: %d\n", strlen(key_data));

  unsigned char* digest;
  
  digest = HMAC(EVP_sha1(), key_data, strlen(key_data), (unsigned char*)data_line, strlen(data_line), NULL, NULL);    
 
    //SHA1 produces a 20-byte hash value which rendered as 40 characters.
    char mdString[20];
    for(int i = 0; i < 20; i++)
         sprintf(&mdString[i*2], "%02x", (unsigned int)digest[i]);
 
    printf("HMAC digest: %s\n", mdString);
    
    FILE *fp1;
    fp1 = fopen(global_hmac_file, "w");        // ENTER TEXT TO FILE
      if (fp1 == NULL)
    {
        printf("Error opening file in function!\n");
        exit(1);
    }
    if(fprintf(fp1, "%s", mdString)<0)
    {
      perror("\n WRITE ERROR : ");
      return 1;
    }
    printf("HMAC Hash Successfully Generated !!!");
    fclose(fp1);


 
  return 0;
}


int main()
{

  
  
  char filepath[1024];
  printf("Enter Complete File Path : ");
  gets(filepath);
  char *perm_file;
  char *HMAC_file;
  perm_file = malloc(sizeof("a")*1024+1);
  HMAC_file = malloc(sizeof("a")*1024+1);
  strcpy(perm_file,filepath);
  strcat(perm_file,".perm");
  
  strcpy(HMAC_file,filepath);
  strcat(HMAC_file,".hmac");

  char *main_dir_path = malloc(sizeof("a")*1024+1);
  strcpy(main_dir_path,filepath);
      
  char *temp_path = malloc(sizeof("a")*1024+1);
  strcpy(temp_path,filepath);


  global_perm_file = malloc(sizeof("a")*1024+1);
  strcpy(global_perm_file,perm_file);
  
  global_hmac_file = malloc(sizeof("a")*1024+1);
  strcpy(global_hmac_file,HMAC_file);
  

  uid_t current_user;
  uid_t current_gid;
  current_user = getuid();
  if(current_user == 1002)
  { 
    current_gid = 1004;
  }
  else if(current_user == 1003)
  {
    current_gid = 1004;
  }
  else if(current_user == 1004)
  {
    current_gid = 1009;
  }
  else if(current_user == 1009)
  {
    current_gid = 1005;
  }
  else if(current_user == 1006)
  {
    current_gid = 1010;
  }
  char s[2]="/";            
  char *token1;
  char *token2;
  char *token3;
  char *token4;
  char *token5;
  char *token6;
  token1 = strtok(temp_path, s);
  token2 = strtok(NULL, s);
  token3 = strtok(NULL, s);
  token4 = strtok(NULL, s);
  token5 = strtok(NULL, s);
  token6 = strtok(NULL, s);
    

  char *current_user_name = malloc(sizeof("a")*100+1);
  
  printf("\nOwner Username : %s\n",token6);
  printf("\nCurrent User : %d\n",current_user);   
  printf("\nCurrent User name : %s\n",uid_to_name(current_user));   
  
  char *str_temp = malloc(sizeof("a")*100+1);
  printf("\nOwner Username : %s\n",token6);
  strcpy(str_temp, uid_to_name(current_user));
  printf("\nOwner Username : %s\n",token6); 
    
  strcpy(current_user_name,str_temp);
  printf("\nOwner Username : %s\n",token6); 
  printf("\nOwner user id : %d",name_to_uid(token6)); 
  printf("\nOwner group id : %d",name_to_gid(token6));  
  


  if(setegid(0))
  {
    perror("(user)ERROR :setegid");
    return 1;
  }
  
  if(setegid(name_to_gid(token6)))
  {
    perror("ERROR :currentgid setgid");
    return 1;
  
  }
  
  if(current_user == 0)
  {
    printf("\nGOING TO CHANGE\n");
  /*  if(setegid(0))
    {
      perror("(Root)ERROR :setegid");
      return 1;
    }
    
    if(setegid(name_to_gid(token6)))
    {
      perror("ERROR :currentgid setgid");
      return 1;
    
    }
  */  
    if(seteuid(0))
    {
      perror("ERROR :msetuid");
      return 1;
    }
  
    if(seteuid(name_to_uid(token6)))
    {
      perror("ERROR :setuid");
      return 1;
    }
    
    if( access( perm_file, F_OK ) != -1 ) {
        // file exists
      printf("\nPerm file : %s exists\n",perm_file);
      printf("\nDir path to create : %s exists\n",filepath);
    
      if(readfromFile(filepath))      
      {
        printf("\nDir path to create : %s\n",filepath);
        perror("readfromfile root0 ");
        return 1;
      }
    } else 
    {
        
      printf("\nFile Doesn't Exist!!\n");
      
    }

  
  }   

  else if(name_to_uid(token6) == current_user)
  {
    
    if(seteuid(0))
    {
      perror("ERROR :msetuid");
      return 1;
    }
  
    if(seteuid(name_to_uid(token6)))
    {
      perror("ERROR :setuid");
      return 1;
    }
      
    if( access( perm_file, F_OK ) != -1 ) {
        // file exists
      if(readfromFile(filepath))    
      {
        printf("\nFILE path to read : %s\n",filepath);
        
        perror("wroe to file user0 : ");
        return 1;
      }
    } else 
    {
      printf("\nFile Doesn't Exist!!\n");
    }   
    
          
    
      
  }
  else  
  {
    printf("\nOwner user id : %d",name_to_uid(token6)); 
    printf("\nOwner group id : %d",name_to_gid(token6));  
    printf("\nCurrent user id : %d",geteuid()); 
    printf("\nCurrent group id : %d",getegid());  
  
    /*if(setegid(0))
    {
      perror("(user)ERROR :setegid");
      return 1;
    }
    
    if(setegid(name_to_gid(token6)))
    {
      perror("ERROR :currentgid setgid");
      return 1;
    
    }*/
    
    if(seteuid(0))
    {
      perror("ERROR :mseteuid");
      return 1;
    }
  
    if(seteuid(name_to_uid(token6)))
    {
      perror("ERROR :seteuid");
      return 1;
    }
    printf("\nChanged user id : %d",geteuid()); 
    printf("\nChanged group id : %d",getegid());  
  
      
    char *path_builder;
    path_builder = malloc(strlen("a")*1024+1);
    const char s[2] = "/";
    char *token1;
           
    int token_counter = 0;        //1 (-1)  -> ignore first         
        
    char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
        
    strcpy(duplicate_for_token_path, filepath);       

    token1 = strtok(duplicate_for_token_path, s);
    


    int childpermfileexists = 0;
    if( access( perm_file, F_OK ) != -1 ) 
    {         
      childpermfileexists = 1;
    }
    else
    {
      childpermfileexists = 0;
    }


       
    if(childpermfileexists == 1)
    {
      

      FILE *f = fopen(perm_file, "r");
      if (f == NULL)
      {
          printf("Error opening file!\n");
          exit(1);
      }
        
      printf("R1d\n");

      char * line = NULL;
      ssize_t read; 
      size_t len = 0;
      int usernotexist = 1;
      while((read = getline(&line, &len, f)) != -1)
      { 
        printf("R2d\n");
        //printf("\nline : %s", line);
        printf("\nLine_d: %s current_user: %s\n",line,current_user_name);
        if(strstr(line, current_user_name) != NULL)   //Perm File contains user entry
        {
          printf("R3d\n");
          usernotexist = 0;
          char s[2]=":";            
          char *token1;
          char *token2;
          token1 = strtok(line, s);
          token2 = strtok(NULL, s);
          if(strstr(token2,"r") != NULL ||(strstr(token2,"a") != NULL))
          {

            printf("You Do Not Have Encipher/Decipher Permissions.Terminating!! ");
            return 0;   
           
          }
          else if(strstr(token2,"rd") != NULL ||(strstr(token2,"ad") != NULL))
          {
            
            printf("\nGOING TO CHANGE_d");
            if(readfromFile(filepath))    
            {
              printf("\nFILE path to read content : %s\n",filepath);
        
              perror("readfromfilee other");
              return 1;
            }
          
            printf("File Successfully Read. Terminating!! \n");
              
            return 0;   
            
          }
          
            
        }
        
      }
      if(usernotexist == 1)
      {
        printf("You Do Not Have Reading Permissions for this file.Terminating!!!\n");
        return 0;   
    
      }




    }
    else          //CHILD PERM FILE DOESNT EXISTS CHECKIING PARENT DIR NOW
    {
      printf("\nFile Doesn't Exist!!\n");
      
    }
  
  

  } 
  




/*
    printf("\nCurrent User1 : %d\n",geteuid());   
  
  printf("\nCurrent User2 : %d\n",getuid());
  if( access( filepath, F_OK ) != -1 ) 
  {
    // file exists
    if( access( filepath, W_OK ) != -1 ) 
    {
          // HAVE PERMISSION
        
      
      FILE *f = fopen(perm_file, "r");
      if (f == NULL)
      {
          printf("Error opening file!\n");
          exit(1);
      }
        
      printf("R1\n");

      char * line = NULL;
      ssize_t read;
      size_t len = 0; 
      printf("ACL File : \n");
      while((read = getline(&line, &len, f)) != -1)
      { 
        printf("%s", line);
        
      }
      
    } 
    else
    {
      
      printf("Dont have reqd File Permissions.Terminating!! ");
      return 0;   
  
    }
  } 
  else 
  {
      // file doesn't exist
    printf("File Doesnt exists.Terminating!! ");
    return 0;   
  
  }

*/
  printf("RNORMALEXIT\n");
  return 2;
}










































/*
int main(int argc, char **argv)
{
  // "opaque" encryption, decryption ctx structures that libcrypto uses to record
  //   status of enc/dec operations 
  EVP_CIPHER_CTX en, de;

  // 8 bytes to salt the key_data during key generation. This is an example of
  //   compiled in salt. We just read the bit pattern created by these two 4 byte 
  //   integers on the stack as 64 bits of contigous salt material - 
  //   ofcourse this only works if sizeof(int) >= 4 
  unsigned int salt[] = {12345, 54321};
  unsigned char *key_data;
  int key_data_len, i;
  char *input[] = {"a", "abcd", "this is a test", "this is a bigger test", 
                   "\nWho are you ?\nI am the 'Doctor'.\n'Doctor' who ?\nPrecisely!",
                   NULL};

  // the key_data is read from the argument list 
  printf("\nEnter Passphrase : ");
  char *temp_string1 = (char *)malloc(sizeof(char)*200+1);
  scanf("%s",temp_string1);
  
  key_data = (unsigned char *)temp_string1;
  //key_data = (unsigned char *)argv[1];
  key_data_len = strlen(key_data);
  
  // gen key and iv. init the cipher ctx object 
  if (aes_init(key_data, key_data_len, (unsigned char *)&salt, &en, &de)) {
    printf("Couldn't initialize AES cipher\n");
    return -1;
  }

  // encrypt and decrypt each input string and compare with the original 
  for (i = 0; input[i]; i++) {
    char *plaintext;
    unsigned char *ciphertext;
    int olen, len;
    char *temp_string2 = (char *)malloc(sizeof(char)*200+1);
   
    // The enc/dec functions deal with binary data and not C strings. strlen() will 
    //   return length of the string without counting the '\0' string marker. We always
    //   pass in the marker byte to the encrypt/decrypt functions so that after decryption 
    //   we end up with a legal C string 
      
    printf("\nEnter Text : ");
    scanf("%s",temp_string2);
    
    input[i] = (unsigned char *)temp_string2;  

    olen = len = strlen(input[i])+1;
    
    ciphertext = aes_encrypt(&en, (unsigned char *)input[i], &len);
    printf("\nCiphertext : %s",ciphertext);
    
    plaintext = (char *)aes_decrypt(&de, ciphertext, &len);
    printf("\nDeciphered text : %s",plaintext);
    if (strncmp(plaintext, input[i], olen)) 
      printf("FAIL: enc/dec failed for \"%s\"\n", input[i]);
    else 
      printf("OK: enc/dec ok for \"%s\"\n", plaintext);
    
    free(ciphertext);
    free(plaintext);
  }

  EVP_CIPHER_CTX_cleanup(&en);
  EVP_CIPHER_CTX_cleanup(&de);

  return 0;
}*/