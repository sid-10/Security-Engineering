#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <pwd.h>
#include <unistd.h>

uid_t name_to_uid(char const *name)
{
  if (!name)
    return -1;
  long const buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
    return -1;
  // requires c99
  char buf[buflen];
  struct passwd pwbuf, *pwbufp;
  if (0 != getpwnam_r(name, &pwbuf, buf, buflen, &pwbufp)
      || !pwbufp)
    return -1;
  return pwbufp->pw_uid;
}

uid_t name_to_gid(char const *name)
{
  if (!name)
    return -1;
  long const buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
    return -1;
  // requires c99
  char buf[buflen];
  struct passwd pwbuf, *pwbufp;
  if (0 != getpwnam_r(name, &pwbuf, buf, buflen, &pwbufp)
      || !pwbufp)
    return -1;
  return pwbufp->pw_gid;
}



int main()
{

	
	
	char filepath[1024];
	printf("Enter Complete Path of file : ");
	gets(filepath);
	char *temp_path = malloc(sizeof("a")*1024+1);
	strcpy(temp_path,filepath);


	int current_user;
	current_user = getuid();
	
	char s[2]="/";						
	char *token1;
	char *token2;
	char *token3;
	char *token4;
	char *token5;
	char *token6;
	token1 = strtok(temp_path, s);
	token2 = strtok(NULL, s);
	token3 = strtok(NULL, s);
	token4 = strtok(NULL, s);
	token5 = strtok(NULL, s);
	token6 = strtok(NULL, s);
	printf("\nCurrent User : %d\n",current_user);		
		
	printf("\nUsername : %s\n",token6);	
	printf("\nChanging to user id : %d",name_to_uid(token6));	
	
	/*if(seteuid(0))
	{
		perror("msetuid");
		return 1;
	}
	
	if(seteuid(name_to_uid(token6)))
	{
		perror("setuid");
		return 1;
	}*/
	int owner = 0;
	printf("\ntemp1 : %d",name_to_uid("fakeroot"));
	printf("\ntemp2 : %d",current_user);		
	if(name_to_uid("fakeroot") == current_user)
	{
		printf("\nGOING TO CHANGE");
		if(seteuid(0))
		{
			perror("msetuid");
			return 1;
		}
	
		if(seteuid(name_to_uid(token6)))
		{
			perror("setuid");
			return 1;
		}
		owner = 1;	
	}	
	
	printf("\nCurrent User1 : %d\n",geteuid());		
	
	if(current_user == name_to_uid(token6))
	{
		owner = 1;		
	}



	printf("\nCurrent User2 : %d\n",getuid());
	if( access( filepath, F_OK ) != -1 ) 
	{
		// file exists
		if( access( filepath, W_OK ) != -1  || owner == 1) 
		{
			if(setegid(0))
		  	{
			    perror("(user)ERROR :setegid");
			    return 1;
		  	}
		  
		  	if(setegid(name_to_gid(token6)))
			{
			    perror("ERROR :currentgid setgid");
			    return 1;
			  
			}
			    // HAVE PERMISSION
			char usertoAdd[1024];
			printf("Enter Username : ");
			gets(usertoAdd);
			printf("%i\n", name_to_uid(usertoAdd));

			char *readorWrite = malloc(sizeof("a")*10+1);
			printf("Enter r(read) or a(all) or rem (to remove): ");
			scanf("%s",readorWrite);
			printf("Hi0\n");			
			int usernotexist = 1;
			printf("Hi1\n");
			if(strcmp(readorWrite,"r")==0)
			{	
				printf("Hi2\n");
				char *perm_file;
				perm_file = malloc(sizeof("a")*1024+1);
				perm_file = filepath;
				strcat(perm_file,".perm");
				char *main_perm_path = malloc(sizeof("a")*1024+1);;
				strcpy(main_perm_path,perm_file);
	 				
				printf("PERM FILE NEW PATH : %s\n",perm_file);
				
				FILE *f = fopen(perm_file, "a+");
				if (f == NULL)
				{
				    printf("Error opening file!\n");
				    exit(1);
				}
				
				printf("R1\n");

				char * line = NULL;
				ssize_t read;
				size_t len = 0;
				while((read = getline(&line, &len, f)) != -1)
				{	
					printf("R2\n");
					//printf("\nline : %s", line);
					if(strstr(line, usertoAdd) != NULL)		//Perm File contains user entry
					{
						printf("R3\n");
						usernotexist = 0;
						char s[2]=":";						
						char *token1;
						char *token2;
						token1 = strtok(line, s);
						token2 = strtok(NULL, s);
						if(strstr(token2,"r") != NULL)
						{
							printf("Read Permission already given to user.Terminating!! ");
							return 0;		
						}
						else if(strstr(token2,"a") != NULL)
						{
							printf("Read Permission already given to user.Terminating!! ");
							return 0;		
						
						}
						
						
					}
					
				}

				fclose(f);
				if(usernotexist == 1)						//USER DATA IS NOT PRESENT
				{
					printf("R4\n");
					FILE *f = fopen(perm_file, "a+");
					if (f == NULL)
					{
					    printf("Error opening file!\n");
					    exit(1);
					}
				
					
					char *texttoWrite = usertoAdd;			
					strcat(texttoWrite, ":");
					strcat(texttoWrite, readorWrite);
					

					fprintf(f,"%s\n",texttoWrite);
					fclose(f);
					printf("R5\n");
				}

			}
			else if(strcmp(readorWrite,"a")==0)
			{
				char *perm_file;
				perm_file = malloc(sizeof("a")*1024+1);
				perm_file = filepath;
				
				strcat(filepath,".perm"); 
				
				char *main_perm_path = malloc(sizeof("a")*1024+1);;
				strcpy(main_perm_path,perm_file);
	 			
				FILE *f = fopen(perm_file, "r");
				if (f == NULL)
				{
				    printf("Error opening file!\n");
				    exit(1);
				}
				
				char * line = NULL;
				ssize_t read;
				size_t len = 0;
				while((read = getline(&line, &len, f)) != -1)
				{	
					printf("\noriginal line : %s", line);
					if(strstr(line, usertoAdd) != NULL)		//Perm File contains user entry
					{
						usernotexist = 0;
						
						/*char s[2] = ":";						
						char *token1;
						char *token2;
						token1 = strtok(line, s);
						token2 = strtok(NULL, s);
						if(strstr(token2,"r") != NULL)
						{
							fseek(f, strlen(line)-1, SEEK_SET);
							fputs("a",f);
							printf("Added Write Permission for user.Terminating!! ");
							return 0;		
						}
						else if(strstr(token2,"a") != NULL)
						{
							printf("Write Permission already given to user.Terminating!! ");
							return 0;		
						
						}*/
						
						
					}
					
				}
				fclose(f);
				if(usernotexist == 0)
				{
					printf("User Exists!\n");
					    
					f = fopen(perm_file, "r");
					char *perm_file2;
					perm_file2 = malloc(sizeof("a")*1024+1);
					
					perm_file2 = filepath;
					char *toreplace = main_perm_path;
					printf("\nORIGAMI  : %s", main_perm_path);
						
					strcat(perm_file2,".temp"); 
							
					FILE *f2 = fopen(perm_file2, "a+");
					if (f == NULL || f2 == NULL)
					{
					    printf("Error opening file!\n");
					    exit(1);
					}
					char * line = NULL;
					ssize_t read;
					size_t len = 0;
					while((read = getline(&line, &len, f)) != -1)
					{	
						printf("\noriginal line : %s", line);
						if(strstr(line, usertoAdd) != NULL)		//Overwrite user entry
						{
							char *texttoWrite = usertoAdd;			
							strcat(texttoWrite, ":");
							strcat(texttoWrite, readorWrite);
					
							fprintf(f2,"%s\n",texttoWrite);
							printf("\nModified line : %s", texttoWrite);
						
						}
						
						else
						{
							printf("\ncopied line : %s", line);
						
							fprintf(f2,"%s",line);
									
						}
				
					}
					fclose(f);
					fclose(f2);
					printf("\nperm_file1 : %s", main_perm_path);
					printf("\nperm_file2 : %s", perm_file2);
							
					remove(main_perm_path);
					rename(perm_file2, main_perm_path);
				
				}
				
				if(usernotexist == 1)						//USER DATA IS NOT PRESENT
				{
					FILE *f = fopen(perm_file, "a+");
					if (f == NULL)
					{
					    printf("Error opening file!\n");
					    exit(1);
					}
				
					
					char *texttoWrite = usertoAdd;			
					strcat(texttoWrite, ":");
					strcat(texttoWrite, readorWrite);
					

					fprintf(f,"%s\n",texttoWrite);
					fclose(f);

				}

			}
			else if(strcmp(readorWrite,"rem")==0)
			{
				char *perm_file;
				perm_file = malloc(sizeof("a")*1024+1);
				perm_file = filepath;
				
				strcat(filepath,".perm"); 
				
				char *main_perm_path = malloc(sizeof("a")*1024+1);;
				strcpy(main_perm_path,perm_file);
	 			
				FILE *f = fopen(perm_file, "r");
				if (f == NULL)
				{
				    printf("Error opening file!\n");
				    exit(1);
				}
				
				char * line = NULL;
				ssize_t read;
				size_t len = 0;
				while((read = getline(&line, &len, f)) != -1)
				{	
					printf("\noriginal line : %s", line);
					if(strstr(line, usertoAdd) != NULL)		//Perm File contains user entry
					{
						usernotexist = 0;
												
						
					}
					
				}
				fclose(f);
				if(usernotexist == 0)
				{
					printf("User Exists!\n");
					    
					f = fopen(perm_file, "r");
					char *perm_file2;
					perm_file2 = malloc(sizeof("a")*1024+1);
					
					perm_file2 = filepath;
					char *toreplace = main_perm_path;
					printf("\nORIGAMI  : %s", main_perm_path);
						
					strcat(perm_file2,".temp"); 
							
					FILE *f2 = fopen(perm_file2, "a+");
					if (f == NULL || f2 == NULL)
					{
					    printf("Error opening file!\n");
					    exit(1);
					}
					char * line = NULL;
					ssize_t read;
					size_t len = 0;
					while((read = getline(&line, &len, f)) != -1)
					{	
						printf("\noriginal line : %s", line);
						if(strstr(line, usertoAdd) != NULL)		//Overwrite user entry
						{
								//Dont write this entry to duplicate file(remove this entry)
						}
						
						else
						{
							printf("\ncopied line : %s", line);
						
							fprintf(f2,"%s",line);
									
						}
				
					}
					fclose(f);
					fclose(f2);
					printf("\nperm_file1 : %s", main_perm_path);
					printf("\nperm_file2 : %s", perm_file2);
							
					remove(main_perm_path);
					rename(perm_file2, main_perm_path);
				
				}
				
				if(usernotexist == 1)						//USER DATA IS NOT PRESENT
				{
					FILE *f = fopen(perm_file, "a+");
					if (f == NULL)
					{
					    printf("Error opening file!\n");
					    exit(1);
					}
				
					
					char *texttoWrite = usertoAdd;			
					strcat(texttoWrite, ":");
					strcat(texttoWrite, readorWrite);
					

					fprintf(f,"%s\n",texttoWrite);
					fclose(f);

				}
			}
			else
			{
				printf("Invalid Choice. Terminating!! ");
				return 0;		

			}
			
		} 
		else
		{
			
			printf("Dont have reqd File Permissions.Terminating!! ");
			return 0;		
	
		}
	} 
	else 
	{
	    // file doesn't exist
		printf("File Doesnt exists.Terminating!! ");
		return 0;		
	
	}


	printf("RNORMALEXIT\n");
	return 2;
}
