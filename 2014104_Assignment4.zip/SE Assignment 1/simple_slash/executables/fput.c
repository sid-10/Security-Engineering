#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <pwd.h>
#include <unistd.h>

uid_t name_to_uid(char const *name)
{
  if (!name)
    return -1;
  long const buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
    return -1;
  // requires c99
  char buf[buflen];
  struct passwd pwbuf, *pwbufp;
  if (0 != getpwnam_r(name, &pwbuf, buf, buflen, &pwbufp)
      || !pwbufp)
    return -1;
  return pwbufp->pw_uid;
}
char const * uid_to_name(uid_t uid)
{
  if (uid==0)
    return "root";
  if (!uid)
    return NULL;
  long const buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
    return NULL;
  // requires c99
  char buf[buflen];
  struct passwd pwbuf, *pwbufp;
  if (0 != getpwuid_r(uid, &pwbuf, buf, buflen, &pwbufp)
      || !pwbufp)
    return NULL;
  return pwbufp->pw_name;
}

uid_t name_to_gid(char const *name)
{
  if (!name)
    return -1;
  long const buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
    return -1;
  // requires c99
  char buf[buflen];
  struct passwd pwbuf, *pwbufp;
  if (0 != getpwnam_r(name, &pwbuf, buf, buflen, &pwbufp)
      || !pwbufp)
    return -1;
  return pwbufp->pw_gid;
}



int writeToFile(char *filepath)
{
	FILE *fp;
	fp = fopen(filepath, "w");				// ENTER TEXT TO FILE
   	if (fp == NULL)
	{
	    printf("Error opening file in function!\n");
	    exit(1);
	}

	printf("Enter text to write to File(overwrite any pre-existing text) : \n");				
	char *write_data = malloc(sizeof("a")*1024+1);
	gets(write_data);					
	printf("\nDATA TO WRITE : %s\n", write_data);
	if(fprintf(fp, "%s\n", write_data)<0)
	{
		perror("\n WRITE ERROR : ");
		return 1;
	}
	printf("lolz");			
	fclose(fp);

	return 0;
}


int main()
{

	
	
	char filepath[1024];
	printf("Enter Complete File Path : ");
	gets(filepath);
	char *perm_file;
	perm_file = malloc(sizeof("a")*1024+1);
	strcpy(perm_file,filepath);
	strcat(perm_file,".perm");
	char *main_dir_path = malloc(sizeof("a")*1024+1);
	strcpy(main_dir_path,filepath);
	 		
	char *temp_path = malloc(sizeof("a")*1024+1);
	strcpy(temp_path,filepath);


	uid_t current_user;
	uid_t current_gid;
	current_user = getuid();
	if(current_user == 1002)
	{	
		current_gid = 1004;
	}
	else if(current_user == 1003)
	{
		current_gid = 1004;
	}
	else if(current_user == 1004)
	{
		current_gid = 1009;
	}
	else if(current_user == 1009)
	{
		current_gid = 1005;
	}
	else if(current_user == 1006)
	{
		current_gid = 1010;
	}
	char s[2]="/";						
	char *token1;
	char *token2;
	char *token3;
	char *token4;
	char *token5;
	char *token6;
	token1 = strtok(temp_path, s);
	token2 = strtok(NULL, s);
	token3 = strtok(NULL, s);
	token4 = strtok(NULL, s);
	token5 = strtok(NULL, s);
	token6 = strtok(NULL, s);
		

	char *current_user_name = malloc(sizeof("a")*100+1);
	
	printf("\nOwner Username : %s\n",token6);
	printf("\nCurrent User : %d\n",current_user);		
	printf("\nCurrent User name : %s\n",uid_to_name(current_user));		
	
	char *str_temp = malloc(sizeof("a")*100+1);
	printf("\nOwner Username : %s\n",token6);
	strcpy(str_temp, uid_to_name(current_user));
	printf("\nOwner Username : %s\n",token6);	
		
	strcpy(current_user_name,str_temp);
	printf("\nOwner Username : %s\n",token6);	
	printf("\nOwner user id : %d",name_to_uid(token6));	
	printf("\nOwner group id : %d",name_to_gid(token6));	
	


	if(setegid(0))
	{
		perror("(user)ERROR :setegid");
		return 1;
	}
	
	if(setegid(name_to_gid(token6)))
	{
		perror("ERROR :currentgid setgid");
		return 1;
	
	}
	
	if(current_user == 0)
	{
		printf("\nGOING TO CHANGE\n");
	/*	if(setegid(0))
		{
			perror("(Root)ERROR :setegid");
			return 1;
		}
		
		if(setegid(name_to_gid(token6)))
		{
			perror("ERROR :currentgid setgid");
			return 1;
		
		}
	*/	
		if(seteuid(0))
		{
			perror("ERROR :msetuid");
			return 1;
		}
	
		if(seteuid(name_to_uid(token6)))
		{
			perror("ERROR :setuid");
			return 1;
		}
		
		if( access( perm_file, F_OK ) != -1 ) {
		    // file exists
			printf("\nPerm file : %s exists\n",perm_file);
			printf("\nDir path to create : %s exists\n",filepath);
		
			if(writeToFile(filepath))			//TODO:WRITE TO NEW FILE HERE!!!
			{
				printf("\nDir path to create : %s\n",filepath);
				perror("writetofile root0 ");
				return 1;
			}
		} else 
		{
		    // file doesn't exist
			//printf("\nPerm file : %s doesnt exists\n",perm_file);
			FILE *f = fopen(perm_file, "a+");
			if (f == NULL)
			{
			    printf("Error opening file!\n");
			    exit(1);
			}
			//printf("\n2Perm file : %s doesnt exists\n",perm_file);
			
			char *texttoWrite = malloc(sizeof("a")*1024+1);
			strcpy(texttoWrite, token6);			
			strcat(texttoWrite, ":");
			strcat(texttoWrite, "a");
								
			fprintf(f,"%s\n",texttoWrite);
			fclose(f);
			printf("\n7Perm file : %s doesnt exists\n",perm_file);
			printf("\nFile path to create : %s exists\n",filepath);
		
			if(writeToFile(filepath))			//TODO:WRITE TO NEW FILE HERE!!!
			{
				perror("ERROR 2 writetoFIle :");
				return 1;
			}
		}

	
	}		

	else if(name_to_uid(token6) == current_user)
	{
		
		if(seteuid(0))
		{
			perror("ERROR :msetuid");
			return 1;
		}
	
		if(seteuid(name_to_uid(token6)))
		{
			perror("ERROR :setuid");
			return 1;
		}
			
		if( access( perm_file, F_OK ) != -1 ) {
		    // file exists
			if(writeToFile(filepath))			//TODO:WRITE TO NEW FILE HERE!!!
			{
				printf("\nFILE path to create/modify : %s\n",filepath);
				
				perror("wroe to file user0 : ");
				return 1;
			}
		} else 
		{
		    // file doesn't exist

			printf("\nNEW PERM FILE PATH : %s\n",perm_file);
			FILE *f = fopen(perm_file, "a+");
			if (f == NULL)
			{
			    printf("\nERROR NEW PERM FILE PATH : %s",perm_file);
			    printf("\nCurrent User : %d\n",current_user);		
	
			    printf("\nError opening file!\n");
			    exit(1);
			}
			char *texttoWrite = malloc(sizeof("a")*1024+1);
			strcpy(texttoWrite, token6);			
			strcat(texttoWrite, ":");
			strcat(texttoWrite, "a");
					
			fprintf(f,"%s\n",texttoWrite);
			fclose(f);
			if(writeToFile(filepath))			//TODO:WRITE TO NEW FILE HERE!!!
			{
				printf("\nFile path to create : %s\n",filepath);
				
				perror("File write user");
				return 1;
			}
		}		
		
					
		
			
	}
	else	
	{
		printf("\nOwner user id : %d",name_to_uid(token6));	
		printf("\nOwner group id : %d",name_to_gid(token6));	
		printf("\nCurrent user id : %d",geteuid());	
		printf("\nCurrent group id : %d",getegid());	
	
		/*if(setegid(0))
		{
			perror("(user)ERROR :setegid");
			return 1;
		}
		
		if(setegid(name_to_gid(token6)))
		{
			perror("ERROR :currentgid setgid");
			return 1;
		
		}*/
		
		if(seteuid(0))
		{
			perror("ERROR :mseteuid");
			return 1;
		}
	
		if(seteuid(name_to_uid(token6)))
		{
			perror("ERROR :seteuid");
			return 1;
		}
		printf("\nChanged user id : %d",geteuid());	
		printf("\nChanged group id : %d",getegid());	
	
			
		char *path_builder;
		path_builder = malloc(strlen("a")*1024+1);
		const char s[2] = "/";
		char *token1;
				   
		int token_counter = 0;				//1 (-1)  -> ignore first 				
				
		char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
		strcpy(duplicate_for_token_path, filepath);				

		token1 = strtok(duplicate_for_token_path, s);
		


		int childpermfileexists = 0;
		if( access( perm_file, F_OK ) != -1 ) 
		{		    	
			childpermfileexists = 1;
		}
		else
		{
			childpermfileexists = 0;
		}


		   
		if(childpermfileexists == 1)
		{
			

			FILE *f = fopen(perm_file, "r");
			if (f == NULL)
			{
			    printf("Error opening file!\n");
			    exit(1);
			}
				
			printf("R1d\n");

			char * line = NULL;
			ssize_t read;	
			size_t len = 0;
			int usernotexist = 1;
			while((read = getline(&line, &len, f)) != -1)
			{	
				printf("R2d\n");
				//printf("\nline : %s", line);
				printf("\nLine_d: %s current_user: %s\n",line,current_user_name);
				if(strstr(line, current_user_name) != NULL)		//Perm File contains user entry
				{
					printf("R3d\n");
					usernotexist = 0;
					char s[2]=":";						
					char *token1;
					char *token2;
					token1 = strtok(line, s);
					token2 = strtok(NULL, s);
					if(strstr(token2,"r") != NULL)
					{
						printf("You Do Not Have Writing Permissions.Terminating!! ");
						return 0;		
					}
					else if(strstr(token2,"a") != NULL)
					{
						printf("\nGOING TO CHANGE_d");
								/*if(seteuid(0))
								{
									perror("msetuid");
									return 1;
								}
	
								if(seteuid(name_to_uid(token6)))
								{
									perror("setuid");
									return 1;
								}
								*/
						if(writeToFile(filepath))
						{
							printf("\nFILE path to update content : %s\n",filepath);
				
							perror("writetofilee other");
							return 1;
						}
					
						printf("File Successfully Updated. Terminating!! ");
							
						return 0;		
						
					}
					
						
				}
				
			}
			if(usernotexist == 1)
			{
				printf("You Do Not Have Writing Permissions to this file.Terminating!!! ");
				return 0;		
		
			}




		}
		else					//CHILD PERM FILE DOESNT EXISTS CHECKIING PARENT DIR NOW
		{
			while( token1 != NULL ) 
		 	{
				token1 = strtok(NULL, s);				//Count all tokens
				token_counter++;
			}
				
			duplicate_for_token_path = NULL;
			duplicate_for_token_path = malloc(strlen("a")*1024+1);
			strcpy(duplicate_for_token_path, filepath);				
					  	
				
			token1 = strtok(duplicate_for_token_path, s);
								
			int temp_counter = 0;
			strcpy(path_builder,"/");					//Building path except the last token
				
			strcat(path_builder, token1);
				
			while( token1 != NULL && temp_counter<token_counter-2) 
		 	{
					
				token1 = strtok(NULL, s);
				printf("\n\nAdding :/%s\n",token1);		
				strcat(path_builder, "/");					
				strcat(path_builder, token1);
				temp_counter++;

			}
			strcat(path_builder, ".perm");					
				
			printf("Path for perm file to check : %s\n",path_builder);



			
			FILE *f = fopen(path_builder, "r");
			if (f == NULL)
			{
			    printf("Error opening file!\n");
			    exit(1);
			}
				
			printf("R1\n");

			char * line = NULL;
			ssize_t read;	
			size_t len = 0;
			int usernotexist = 1;
			while((read = getline(&line, &len, f)) != -1)
			{	
					printf("R2\n");
					//printf("\nline : %s", line);
				printf("\nLine: %s current_user: %s\n",line,current_user_name);
				if(strstr(line, current_user_name) != NULL)		//Perm File contains user entry
				{
					printf("R3\n");
					usernotexist = 0;
					char s[2]=":";						
					char *token1;
					char *token2;
					token1 = strtok(line, s);
					token2 = strtok(NULL, s);
					if(strstr(token2,"r") != NULL)
					{
						printf("You Do Not Have Writing Permissions.Terminating!! ");
						return 0;		
					}
					else if(strstr(token2,"a") != NULL)
					{
						printf("\nGOING TO CHANGE");
								/*if(seteuid(0))
								{
									perror("msetuid");
									return 1;
								}
	
								if(seteuid(name_to_uid(token6)))
								{
									perror("setuid");
									return 1;
								}
								*/
						if(writeToFile(filepath))
						{
							printf("\nwrit to File path to create : %s\n",filepath);
				
							perror("writ other");
							return 1;
						}
					
						printf("File Successfully Created. Terminating!! ");
							
						return 0;		
						
					}
					
						
				}
				
			}
			if(usernotexist == 1)
			{
				printf("You Do Not Have Writing Permissions.Terminating!!! ");
				return 0;		
		
			}
		
		}//end of parent dir perm check else condition



			
	

	}	
	








/*
		printf("\nCurrent User1 : %d\n",geteuid());		
	
	printf("\nCurrent User2 : %d\n",getuid());
	if( access( filepath, F_OK ) != -1 ) 
	{
		// file exists
		if( access( filepath, W_OK ) != -1 ) 
		{
			    // HAVE PERMISSION
				
			
			FILE *f = fopen(perm_file, "r");
			if (f == NULL)
			{
			    printf("Error opening file!\n");
			    exit(1);
			}
				
			printf("R1\n");

			char * line = NULL;
			ssize_t read;
			size_t len = 0;	
			printf("ACL File : \n");
			while((read = getline(&line, &len, f)) != -1)
			{	
				printf("%s", line);
				
			}
			
		} 
		else
		{
			
			printf("Dont have reqd File Permissions.Terminating!! ");
			return 0;		
	
		}
	} 
	else 
	{
	    // file doesn't exist
		printf("File Doesnt exists.Terminating!! ");
		return 0;		
	
	}

*/
	printf("RNORMALEXIT\n");
	return 2;
}
