#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <pwd.h>
#include <unistd.h>

uid_t name_to_uid(char const *name)
{
  if (!name)
    return -1;
  long const buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
    return -1;
  // requires c99
  char buf[buflen];
  struct passwd pwbuf, *pwbufp;
  if (0 != getpwnam_r(name, &pwbuf, buf, buflen, &pwbufp)
      || !pwbufp)
    return -1;
  return pwbufp->pw_uid;
}




int main()
{

	
	
	char filepath[1024];
	printf("Enter Complete Path of file : ");
	gets(filepath);
	char *perm_file;
	perm_file = malloc(sizeof("a")*1024+1);
	perm_file = filepath;
	strcat(perm_file,".perm");
	char *main_perm_path = malloc(sizeof("a")*1024+1);;
	strcpy(main_perm_path,perm_file);
	 		
	char *temp_path = malloc(sizeof("a")*1024+1);
	strcpy(temp_path,filepath);


	int current_user;
	current_user = getuid();
	
	char s[2]="/";						
	char *token1;
	char *token2;
	char *token3;
	char *token4;
	char *token5;
	char *token6;
	token1 = strtok(temp_path, s);
	token2 = strtok(NULL, s);
	token3 = strtok(NULL, s);
	token4 = strtok(NULL, s);
	token5 = strtok(NULL, s);
	token6 = strtok(NULL, s);
	printf("\nCurrent User : %d\n",current_user);		
		
	printf("\nUsername : %s\n",token6);	
	printf("\nChanging to user id : %d",name_to_uid(token6));	
	
	/*if(seteuid(0))
	{
		perror("msetuid");
		return 1;
	}
	
	if(seteuid(name_to_uid(token6)))
	{
		perror("setuid");
		return 1;
	}*/
	printf("\ntemp1 : %d",name_to_uid("fakeroot"));
	printf("\ntemp2 : %d",current_user);		
	
		printf("\nGOING TO CHANGE");
		if(seteuid(0))
		{
			perror("msetuid");
			return 1;
		}
	
		if(seteuid(name_to_uid(token6)))
		{
			perror("setuid");
			return 1;
		}	
	
	printf("\nCurrent User1 : %d\n",geteuid());		
	
	printf("\nCurrent User2 : %d\n",getuid());
	if( access( filepath, F_OK ) != -1 ) 
	{
		// file exists
		if( access( filepath, W_OK ) != -1 ) 
		{
			    // HAVE PERMISSION
				
			
			FILE *f = fopen(perm_file, "a+");
			if (f == NULL)
			{
			    printf("Error opening file!\n");
			    exit(1);
			}
				
			printf("R1\n");

			char * line = NULL;
			ssize_t read;
			size_t len = 0;	
			printf("ACL File : \n");
			while((read = getline(&line, &len, f)) != -1)
			{	
				printf("%s", line);
				
			}
			
		} 
		else
		{
			
			printf("Dont have reqd File Permissions.Terminating!! ");
			return 0;		
	
		}
	} 
	else 
	{
	    // file doesn't exist
		printf("File Doesnt exists.Terminating!! ");
		return 0;		
	
	}


	printf("RNORMALEXIT\n");
	return 2;
}
