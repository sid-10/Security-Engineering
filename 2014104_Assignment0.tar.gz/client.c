#include<stdio.h> //printf
#include<string.h>    //strlen
#include<sys/socket.h>    //socket
#include<arpa/inet.h> //inet_addr
#include <unistd.h>  //close 
int main(int argc , char *argv[])
{
    int sock;
    struct sockaddr_in server;
    char message[1001];
     
    //Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");
     
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons( 8888 );
 
    //Connect to remote server
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("connect failed. Error");
        return 1;
    }
     
    puts("Connected\n");

	char server_reply[2000];
        
	char temp_server_reply[2000];
        
	


	int read_size =  recv(sock , server_reply , 2000 , 0);
        if(read_size < 0)
        {
            puts("recv failed");
        }
        server_reply[read_size] = '\0'; 
 	puts(server_reply);
	//memset(server_reply, 0, read_size);				//Recieve Who are you from Server.
       
	printf("Enter username : ");
        fgets(message, 1000, stdin);
        message[strlen(message)-1] = '\0'; 
	printf("\n");
        								//Send username 
        if( send(sock , message , strlen(message) , 0) < 0)
        {
            puts("Send failed");
            return 1;
        }


	printf("Enter group name : ");
        fgets(message, 1000, stdin);
        message[strlen(message)-1] = '\0'; 
	printf("\n");
        								//Send groupname 
        if( send(sock , message , strlen(message) , 0) < 0)
        {
            puts("Send failed");
            return 1;
        }


	//memset(server_reply, 0, read_size);
read_size = 0;
	read_size =  recv(sock , server_reply , 2000 , 0);    //Recieve Hello 'user' from Server + prompt changes to username.		
        if(read_size < 0)
        {
            puts("recv failed");
        }
	
	server_reply[read_size+1] = '\0'; 
 	printf("%s",server_reply);
	//memset(server_reply, 0, read_size);
        
     
    //keep communicating with server
    while(1)
    {
	
	//printf("Enter message : ");
        fgets(message, 1000, stdin);
	message[strlen(message)-1] = '\0';
        //Send data
        if( send(sock , message , strlen(message) , 0) < 0)
        {
            puts("Send failed");
            return 1;
        }
         
        //Receive a reply from the server
	read_size =  recv(sock , temp_server_reply , 2000 , 0);
	//printf("Read Size : %d \n",read_size);
        if(read_size < 0)
        {
            puts("recv failed");
            break;
        }
        temp_server_reply[read_size] = '\0';
	
	puts("Server reply :");
        printf("%s",temp_server_reply);
	
//	memset(temp_server_reply, 0, read_size);
    }
     
    close(sock);
    return 0;
}
