
#include<stdio.h>
#include<malloc.h>
#include<string.h>    //strlen
#include<stdlib.h>    //strlen
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h>    //write
#include<pthread.h> //for threading , link with lpthread

#include <sys/stat.h>		//for mkdir
#include <sys/types.h>
#include <dirent.h>		//for ls and cd (opendir)
#include <errno.h>

//the thread function
void *connection_handler(void *);


char* all_users[20];							//stores all users (even logged out).
char* logged_in_users[20];						//stores currently logged in users to prevent multiple signins.
int logged_in_counter = 0, all_counter = 0;

 

char *strip_n_copy(const char *s) {
    char *p = malloc(strlen(s) + 1);
    if(p) {
        char *p2 = p;
        while(*s != '\0') {
            if(*s != '\t' && *s != '\n') {
                *p2++ = *s++;
            } else {
                ++s;
            }
        }
        *p2 = '\0';
    }
    return p;
}


void removeSubstring(char* s, const char* toremove)
{
	while(s = strstr(s,toremove))
		memmove(s,s+strlen(toremove),1+strlen(s+strlen(toremove)));
}

int dirExists(char* path)
{
	DIR* dir = opendir(path);
	if (dir)
	{
	    						/* Directory exists. */
	   closedir(dir);
	   printf("Returning 1\n");
	    return 1;
	}
	else if (ENOENT == errno)
	{
		printf("Returning 0\n");
	    return 0;					/* Directory does not exist. */
	}
	
	printf("Returning -1\n");
	return -1;					//opendir failed.
	

}

static void _mkdir(const char *dir, char* current_user, char* current_user_group) {
        char tmp[256];
        char *p = NULL;
        size_t len;
	snprintf(tmp, sizeof(tmp),"%s",dir);
        len = strlen(tmp);
        if(tmp[len - 1] == '/')
                tmp[len - 1] = 0;
        for(p = tmp + 1; *p; p++)
                if(*p == '/') {
                        printf("meu DIR PATH maybe create : %s\n",tmp);
        		*p = 0;
                        mkdir(tmp, S_IRWXU);

			if(strstr(tmp, "simple_slash/simple_home/user") != NULL){
				FILE *fp;
				   char* perm_file = malloc(strlen("a")*500+1);
				printf( "meu  Dir path pkka create :  %s\n",tmp); 






				char path_builder[1024];
				
				const char s[2] = "/";
				char *token;
				   
				int token_counter = 0;				//1 (-1)  -> ignore first 				
				
				char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, tmp);				

				/* get the first token */
				token = strtok(duplicate_for_token_path, s);
				   
				/* walk through other tokens */
				while( token != NULL ) 
			 	{
					//printf( "token  %s\n", token);    
					token = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				//printf("token counter %d\n", token_counter);    
				
				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				strcpy(duplicate_for_token_path, tmp);				
				  	
				
				token = strtok(duplicate_for_token_path, s);
								
				int temp_counter = 1;
				strcpy(path_builder,"/");					//Building path except the last token
				
				strcat(path_builder, token);
				
				while( token != NULL) 
			 	{
					if(temp_counter>=(token_counter-1))
					{
						token = strtok(NULL, s);
						break;			
					}					
					token = strtok(NULL, s);		
	//				printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
					strcat(path_builder, "/");					
					strcat(path_builder, token);
					temp_counter++;
					

				}
				



				   strcpy(perm_file, path_builder);
				   



	
    				   strcat(perm_file, "/perm_file.txt");
				   //printf("Here7g PATH : %s\n",perm_file);
				
				int dir_already_permissioned = 0;
				
				if( access( perm_file, F_OK ) != -1 ) {
					printf("Perm File (Path) : %s already exists ",perm_file);
				  				 // file exists check if dir perm is already present
					fp = fopen(perm_file, "r");
					char line[256];

					while (fgets(line, sizeof(line), fp)) 
					{
					
	
						printf("\n line ::: %s\n\n", line); 
						    
								
						const char s[2] = " ";
						char *token1;
					
						char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
						strcpy(duplicate_for_token_path, line);				

						/* get the first token */
						token1 = strtok(duplicate_for_token_path, s);
						
						int t_counter = 1;
						while( token1 != NULL)// && t_counter<2) 
					 	{
									
							printf("\nt counter %d token : %s\n",t_counter, token1);
							if(t_counter == 1)
								break;  			
							token1 = strtok(NULL, s);		
							  	
							t_counter++;
					

						}
	
						printf("\n\n\n MY TOKEN : %s AND TOKEN : %s\n\n",token, token1);
						if(strcmp(token1, token) == 0)
							dir_already_permissioned = 1;
						   

			
					}
					fclose(fp);
					
 				} else 
				{
								
				}
				if(dir_already_permissioned == 0)
				{
				   fp = fopen(perm_file, "a");					//Initialize permission file for directory
				   printf("meu File Address : %s Name : %s\n", perm_file, token); 
					
				   fprintf(fp, "%s %s %s\n",token, current_user, current_user_group);		
				
				   //fputs("parent \n", fp);
				   fclose(fp);
				}
			}

                        *p = '/';
		}
			
        
			   


                
	//printf("Here7h\n");
        mkdir(tmp, S_IRWXU);
	FILE *fp1;
	   char* perm_file1 = malloc(strlen("a")*500+1);
	   








	
				char path_builder[1024];
				
				const char s[2] = "/";
				char *token1;
				   
				int token_counter = 0;				//1 (-1)  -> ignore first 				
				
				char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, tmp);				

				/* get the first token */
				token1 = strtok(duplicate_for_token_path, s);
				   
				/* walk through other tokens */
				while( token1 != NULL ) 
			 	{
					//printf( "token1 : %s\n", token1);    
					token1 = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				//printf("token counter %d\n", token_counter);    
				//printf( "tmp :  %s\n",tmp); 

				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				strcpy(duplicate_for_token_path, tmp);				
				  	
				
				token1 = strtok(duplicate_for_token_path, s);
								
				int temp_counter = 1;
				strcpy(path_builder,"/");					//Building path except the last token
				
				strcat(path_builder, token1);
				
				while( token1 != NULL) 
			 	{
					if(temp_counter>=(token_counter-1))
					{
						token1 = strtok(NULL, s);
						break;			
					}
					token1 = strtok(NULL, s);		
				//	printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token1);    				
					strcat(path_builder, "/");					
					strcat(path_builder, token1);
					temp_counter++;
					

				}
	

	
	strcpy(perm_file1, path_builder);
	   strcat(perm_file1, "/perm_file.txt");
	   fp1 = fopen(perm_file1, "a");
	   						//Initialize permission file for directory
	printf("meu final File Address : %s Name : %s\n",perm_file1, token1);
		 
	  fprintf(fp1, "%s %s %s\n", token1, current_user, current_user_group);
	   //fputs("parent \n", fp);
	   fclose(fp1);

}

int main(int argc , char *argv[])
{
    int i;
    for(i = 0; i < 20; i++)
    {	
	logged_in_users[i] = malloc((strlen("a")*50)+1);		//max length of username = 50		
        all_users[i] = malloc((strlen("a")*50)+1);
    }
    

	struct stat st = {0};

	if (stat("/home/siddharth/Desktop/Security Engineering/simple_slash", &st) == -1) {
	    mkdir("/home/siddharth/Desktop/Security Engineering/simple_slash", 0700);
	}
	if (stat("/home/siddharth/Desktop/Security Engineering/simple_slash/simple_home", &st) == -1) {
	    mkdir("/home/siddharth/Desktop/Security Engineering/simple_slash/simple_home", 0700);
	}



    int socket_desc , client_sock , c , *new_sock;
    struct sockaddr_in server , client;
     
    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");
     
    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons( 8888 );
     
    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    {
        //print the error message
        perror("bind failed. Error");
        return 1;
    }
    puts("bind done");
     
    //Listen
    listen(socket_desc , 3);
     
    //Accept and incoming connection
    puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);
     
     
    //Accept and incoming connection
    //puts("Waiting for incoming connections...");
    //c = sizeof(struct sockaddr_in);
    while( (client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c)) )
    {
        puts("Connection accepted");
         
        pthread_t sniffer_thread;
        new_sock = malloc(1);
        *new_sock = client_sock;
         
        if( pthread_create( &sniffer_thread , NULL ,  connection_handler , (void*) new_sock) < 0)
        {
            perror("could not create thread");
            return 1;
        }
         
        //Now join the thread , so that we dont terminate before the thread
        //pthread_join( sniffer_thread , NULL);
        puts("Handler assigned");
    }
     
    if (client_sock < 0)
    {
        perror("accept failed");
        return 1;
    }
     
    return 0;
}
 
/*
 * This will handle connection for each client
 * */
void *connection_handler(void *socket_desc)
{
    int logged_in = 0;
    char* current_user;							//save current username for removing later from logged_in array
    char* current_user_group;
    //Get the socket descriptor
    int sock = *(int*)socket_desc;
    int read_size;
    int already_logged = 0;
    int already_exists = 0;					//global account already exists
    char *message ;
    char client_message[2000];					//setting max length of client message
      

    char* base_path = "/home/siddharth/Desktop/Security\ Engineering";		

    char* simple_home_path = "/home/siddharth/Desktop/Security\ Engineering/simple_slash/simple_home";
    char* display_simple_home_path = "/simple_slash/simple_home";
		

    message = "Who are you user? \n";
    write(sock , message , strlen(message));
     
    //Receive a message from client
    char* temp_path = malloc(strlen("a")*1024+1);
    char* display_temp_path = malloc(strlen("a")*1024+1);
    
    int initialize = 0;								//To initialize paths for the first time
    printf("Here1\n");
    while( (read_size = recv(sock , client_message , 2000 , 0)) > 0 )
    {

	puts(client_message);
	//Send the message back to client
	client_message[read_size] = '\0';
	printf("Here1a\n");
	if(logged_in == 1 && initialize == 0)
	{	
		strcpy(temp_path, simple_home_path);
		strcat(temp_path, "/");
		strcat(temp_path, current_user);
		strcpy(display_temp_path, display_simple_home_path);
		strcat(display_temp_path, "/");
		strcat(display_temp_path, current_user);
		initialize = 1;

	}	
	printf("Here1b\n");
	if(logged_in == 0)						//Check Login 
	{

        		printf("Here1c\n");
		int i;
		
		for(i = 0; i <= logged_in_counter; i++)
		{	
 			
    			if(!strcmp(logged_in_users[i], client_message))
    			{
        			already_logged = 1;
				printf("Here1d\n");
    			}
		}


		if(already_logged == 1)
		{
			printf("Here1e\n");
			memset(client_message, 0, read_size);
			strcpy(client_message, "Error : User already logged in! Terminating Client. ");
			already_logged = 0;				//Another Login attempt with different user
			int write_size = strlen(client_message);
			write(sock , client_message , write_size);
			memset(client_message, 0, write_size);
			printf("HERE 1F\n");
			return 0;
			
		}
		else if(logged_in_counter==19)
		{
			memset(client_message, 0, read_size);
			strcpy(client_message, "Error : Max number of Users are already Logged in. Terminating Connection!!!");
			int write_size = strlen(client_message);
			write(sock , client_message , write_size);
			memset(client_message, 0, write_size);
			puts("Client disconnected");
			free(socket_desc);
			return 0;
 
		}
		else					//save username to logged_in_users array and to current_user
		{
		
			if(all_counter>=19)				//Check if user already exists if max users are registered
			{
				
				int j;
		
				for(j = 0; j <= all_counter; j++)
				{	
		 			
		    			if(!strcmp(all_users[j], client_message))
		    			{
						already_exists = 1;
		    			}
				}
				if(already_exists == 0)
				{
					memset(client_message, 0, read_size);
					strcpy(client_message, "Error : Max limit of users reached. Terminating Connection!!!");
					int write_size = strlen(client_message);
					write(sock , client_message , write_size);
					memset(client_message, 0, write_size);
					puts("Client disconnected");
					free(socket_desc);
					return 0;
					
				}
			}			


			strcpy(logged_in_users[logged_in_counter],client_message);		//malloc already done while initializing
			strcpy(all_users[all_counter],client_message);				//create user globally
			
			logged_in_counter++;
			all_counter++;

			current_user = malloc(strlen(client_message)+1);
			
			strcpy(current_user, client_message);
			char temp_server_reply[2000];
        
			int read_size_temp =  recv(sock , temp_server_reply , 2000 , 0);
			if(read_size_temp < 0)
			{
			    puts("recv failed");
			    break;
			}
			temp_server_reply[read_size_temp] = '\0';
			current_user_group = malloc(strlen(temp_server_reply)+1);
						
			strcpy(current_user_group, temp_server_reply);
			logged_in = 1;
			
			
			strcpy(client_message,"$");
			strcat(client_message,current_user);			//Building the $username: format
			strcat(client_message,": ");
			printf("Here4\n");
	
		}
		
	char* simple_home_path = "/home/siddharth/Desktop/Security Engineering/simple_slash/simple_home";
	char* temp_path = malloc(strlen("a")*500+1);
	strcpy(temp_path, simple_home_path);
	strcat(temp_path, "/");
	strcat(temp_path, current_user);

		
	struct stat st = {0};

	if (stat(temp_path, &st) == -1  && already_logged == 0) {
	    _mkdir(temp_path,current_user, current_user_group);;				//Create user directory inside home


	  /* FILE *fp;
	   char* perm_file = malloc(strlen("a")*500+1);
	   strcpy(perm_file, simple_home_path);
	   strcat(perm_file, "/perm_file.txt");
	   fp = fopen(perm_file, "a");						//Initialize permission file for directory
	   fprintf(fp, "%s %s %s\n",current_user, current_user, current_user_group);
	   //fputs("parent \n", fp);
	   fclose(fp);
	*/


	}
	
	if(already_logged == 0)
	{	
		struct dirent *pDirent;
		DIR *pDir;

		pDir = opendir (temp_path);						//open the user's directory
		if (pDir == NULL) {
		    printf ("Cannot open directory '%s'\n", temp_path);				//RETURN THIS MESSAGE TO CLIENT
		    //return 1;
		}

		while ((pDirent = readdir(pDir)) != NULL) {
		    printf ("[%s]\n", pDirent->d_name);
		}
			
	 	strcat(client_message,display_simple_home_path);			
		strcat(client_message,"/");
		strcat(client_message, current_user);	
		strcat(client_message,": ");
	
		int write_size = strlen(client_message);
		puts("sending message : ");
		puts(client_message);
	
		write(sock , client_message , write_size);				//Not logged in response sent to client
		memset(client_message, 0, write_size);
        }
	}
	else if(logged_in == 1 && already_logged == 0)
	{
		
		char client_send_message[2000];					//setting max length of client (to send) message
    

				

		
		
		if(strstr(client_message, "pwd") != NULL) 
		{
   		
       			fprintf(stdout, "Current working dir: %s\n", display_temp_path);		//RETURN MESSAGE TO CLIENT. DONE
			strcpy(client_send_message,display_temp_path);			
			strcat(client_send_message,"\n$");
			strcat(client_send_message,current_user);			//Building the $username: format
			strcat(client_send_message,": ");
							
			strcat(client_send_message,display_temp_path);
			strcat(client_send_message,": ");
				
		}
		else if(strstr(client_message, "cd ..") != NULL) 
		{
			if(strcmp(display_temp_path,"/simple_slash")==0)
			{
				
				strcpy(client_send_message,"$");
				strcat(client_send_message,current_user);			//Building the $username: format
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	  //TOPMOST DIRECTORY RETURN JUST $USERNAME
	


			}
			else
			{
		
				char path_builder[1024];
				
				const char s[2] = "/";
				char *token;
				   
				int token_counter = 0;				//1 (-1)  -> ignore first 				
				
				char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, display_temp_path);				

				/* get the first token */
				token = strtok(duplicate_for_token_path, s);
				   
				/* walk through other tokens */
				while( token != NULL ) 
			 	{
					printf( "token[%d] %s\n",token_counter, token);    
					token = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				printf("token counter %d\n", token_counter);    
				printf( "display_temp_path :  %s\n",display_temp_path); 

				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				strcpy(duplicate_for_token_path, display_temp_path);				
				  	
				
				token = strtok(duplicate_for_token_path, s);
								
				int temp_counter = 1;
				strcpy(path_builder,"/");					//Building path except the last token
				
				strcat(path_builder, token);
				
				while( token != NULL && (temp_counter<(token_counter-1))) 
			 	{
					token = strtok(NULL, s);		
					printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
					strcat(path_builder, "/");					
					strcat(path_builder, token);
					temp_counter++;
					

				}
	
				temp_path = NULL;
				temp_path = malloc(strlen("a")*1024+1);
				strcpy(temp_path, base_path);
				strcat(temp_path, path_builder);

				display_temp_path = NULL;
				display_temp_path = malloc(strlen("a")*1024+1);
				printf("\ntemp_path : %s\n",temp_path);
				strcpy(display_temp_path, path_builder);

				strcpy(client_send_message,"$");
				strcat(client_send_message,current_user);			//Building the $username: format
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	  //TOPMOST DIRECTORY RETURN JUST $USERNAME
				strcat(client_send_message,": ");

					
			}



		}		
		else if(strstr(client_message, "cd /simple_slash") != NULL) 		//"Absolute Path"
		{
			
			removeSubstring(client_message, "cd ");

			char* verifyDir = malloc(strlen("a")*2000+1);
			strcpy(verifyDir, base_path);
			strcat(verifyDir, client_message);
			




			const char s_m[2] = "/";
			char *token_m;
			int token_counter_m = 1;
			char* duplicate_for_token_path_m = malloc(strlen("a")*1024+1);
			int perm_granted = 0;
			strcpy(duplicate_for_token_path_m, verifyDir);				

			/* get the first token */
			token_m = strtok(duplicate_for_token_path_m, s_m);

			/* walk through other tokens */
			while( token_m != NULL && token_counter_m!=7) 
		 	{
				printf( "token %s\n", token_m);    
				token_m = strtok(NULL, s_m);				//Count all tokens
				token_counter_m++;
			}
			
			printf("OBTAINED USER NAME?: %s\n",token_m);
			if(strcmp(token_m,current_user)==0)
			{	
				printf("\nHAHAAHAHAHAH Permission Granted to cd \n\n\n");
			
				perm_granted = 1;
			}



			printf("verify Path : %s\n\n",verifyDir);
			
			if(dirExists(verifyDir)==0)
			{
				printf("\n\n\nERROR DIR DOESNT EXIST\n\n\n");
				strcpy(client_send_message,"Directory Does not exist!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");
			}	
			
			else if(dirExists(verifyDir)==1 && perm_granted == 0)			
			{	
				
				
				


				
				
				char path_builder[1024];
				
				const char s[2] = "/";
				char *token1;
				   
				int token_counter = 0;				//1 (-1)  -> ignore first 				
				
				char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, verifyDir);				

				/* get the first token */
				token1 = strtok(duplicate_for_token_path, s);
				   
				/* walk through other tokens */
				while( token1 != NULL ) 
			 	{
					//printf( "token1 : %s\n", token1);    
					token1 = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				//printf("token counter %d\n", token_counter);    
				//printf( "tmp :  %s\n",tmp); 

				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				strcpy(duplicate_for_token_path, verifyDir);				
				  	
				
				token1 = strtok(duplicate_for_token_path, s);
								
				int temp_counter = 1;
				strcpy(path_builder,"/");					//Building path except the last token
				
				strcat(path_builder, token1);
				
				while( token1 != NULL) 
			 	{
					if(temp_counter>=(token_counter-1))
					{
						token1 = strtok(NULL, s);
						break;			
					}
					token1 = strtok(NULL, s);		
				//	printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token1);    				
					strcat(path_builder, "/");					
					strcat(path_builder, token1);
					temp_counter++;
					

				}
	

				char* perm_file1 = malloc(strlen("a")*1024+1);
				strcpy(perm_file1, path_builder);
			 	strcat(perm_file1, "/perm_file.txt");
				FILE *fp1 = fopen(perm_file1, "r");



				

				char line[256];
				char* dir_name = malloc(strlen("a")*1024+1);
				char* dir_owner = malloc(strlen("a")*1024+1);
				char* dir_group = malloc(strlen("a")*1024+1);

				while (fgets(line, sizeof(line), fp1)) 
				{
					
	
					printf("\n line ::: %s\n\n", line); 
					   	
					const char s_m1[2] = " ";
					char *token1_m1;
		
					
					char* duplicate_for_token_path_m1 = malloc(strlen("a")*1024+1);
				
					strcpy(duplicate_for_token_path_m1, line);				

					/* get the first token */
					token1_m1 = strtok(duplicate_for_token_path_m1, s_m1);
						
					int t_counter_m1 = 1;
					while( token1_m1 != NULL)// && t_counter<2) 
				 	{
									
						printf("\nt counter %d token : %s\n",t_counter_m1, token1_m1);
						if(t_counter_m1 == 1)				//file/dir name
							strcpy(dir_name,token1_m1);						
						if(t_counter_m1 == 2)				//owner name
							strcpy(dir_owner,token1_m1);  
						if(t_counter_m1 == 3)				//group name
						{	
							strcpy(dir_group,token1_m1);
							break;  
						}			
						token1_m1 = strtok(NULL, s_m1);		
							  	
						t_counter_m1++;
					

					}
					if(strcmp(token1,dir_name)==0)
					{
						printf("\ndir name %s owner : %s current_user : %s\n",dir_name, dir_owner, current_user);
						printf("\ndir name %s group : %s current_user_group : %s Match? : %d grouplen : %d user_group_len : %d\n",dir_name, dir_group, current_user_group, strcmp(dir_group,current_user_group), (int)strlen(dir_group) , (int)strlen(current_user_group));
						
						char * dir_group_modified = malloc(strlen("a")*1000+1);
						strcpy(dir_group_modified, strip_n_copy(dir_group));
						if(strcmp(dir_owner, current_user)==0)
						{
							perm_granted = 1;
						}
						else if(strcmp(dir_group_modified,current_user_group)==0)
						{
							perm_granted = 1;
						}

					}
		//printf("\n\n\nURGENT TOKEN1 : %s ;DIR_NAME : %s ;DIR_OWNER : %s ;DIR_GROUP : %s\n\n\n",token1,dir_name,dir_owner,dir_group);
				
				}						//end of while read file
	
						
					

			


				if(perm_granted == 1)

				{

					temp_path = NULL;
					display_temp_path = NULL;
			   		temp_path = malloc(strlen("a")*1024+1);
			
					display_temp_path = malloc(strlen("a")*1024+1);
							

					strcpy(temp_path, base_path);
					strcat(temp_path, client_message);
					strcpy(display_temp_path, client_message);
								
					strcpy(client_send_message,"$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	 
					strcat(client_send_message,": ");
				}
				else
				{
			
					strcpy(client_send_message,"You do not have the required permissions!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
				}
				
			}
			else if(perm_granted == 0)
			{
			
				strcpy(client_send_message,"You do not have the required permissions!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");						
			
			}
			
			
		}
		

		else if(strcmp(client_message, "cd simple_home") == 0 && strcmp(display_temp_path, "/simple_slash") == 0) 				//Relative to not merged with next if to handle an error
		{
					removeSubstring(client_message, "cd ");
			
					temp_path = NULL;
					display_temp_path = NULL;
			   		temp_path = malloc(strlen("a")*1024+1);
			
					display_temp_path = malloc(strlen("a")*1024+1);
							

					strcpy(temp_path, base_path);
					strcat(temp_path, "/simple_slash/simple_home");
					strcpy(display_temp_path, "/simple_slash/simple_home");
					
					printf("\ntemp_path : %s\n",temp_path);					
								
					strcpy(client_send_message,"$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	 
					strcat(client_send_message,": ");
		}

		else if(strstr(client_message, "cd ") != NULL) 				//Relative to display_temp_path Path
		{
			//temp_path = NULL;
			//display_temp_path = NULL;
	   		removeSubstring(client_message, "cd ");
			int perm_granted = 0;			
			char* verifyDir = malloc(strlen("a")*2000+1);
			strcpy(verifyDir, temp_path);
			strcat(verifyDir, "/");
			strcat(verifyDir, client_message);
			
			printf("verify Path : %s\n\n",verifyDir);
			if(dirExists(verifyDir)==1)			
			{	
	















				char path_builder[1024];
				
				const char s[2] = "/";
				char *token1;
				   
				int token_counter = 0;				//1 (-1)  -> ignore first 				
				
				char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, verifyDir);				

				/* get the first token */
				token1 = strtok(duplicate_for_token_path, s);
				   
				/* walk through other tokens */
				while( token1 != NULL ) 
			 	{
					//printf( "token1 : %s\n", token1);    
					token1 = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				//printf("123token counter %d\n", token_counter);    
				//printf( "tmp :  %s\n",tmp); 

				
			printf("123HereA");
								
				char* duplicate_for_token_path_2 = malloc(strlen("a")*1024+1);
printf("123HereB");
							
				strcpy(duplicate_for_token_path_2, verifyDir);				
				  	
				printf("123Here0");
				token1 = strtok(duplicate_for_token_path_2, s);
				printf("123Here1");				
				int temp_counter = 1;
				strcpy(path_builder,"/");					//Building path except the last token
				
				strcat(path_builder, token1);
				printf("123Here2");
				while( token1 != NULL) 
			 	{
					if(temp_counter>=(token_counter-1))
					{
						token1 = strtok(NULL, s);
						break;			
					}
					token1 = strtok(NULL, s);		
				//	printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token1);    				
					strcat(path_builder, "/");					
					strcat(path_builder, token1);
					temp_counter++;
					

				}
	
				printf("123Here3");
				char* perm_file1 = malloc(strlen("a")*1024+1);
				strcpy(perm_file1, path_builder);
			 	strcat(perm_file1, "/perm_file.txt");
				FILE *fp1 = fopen(perm_file1, "r");
				printf("123Here4");


				

				char line[256];
				char* dir_name = malloc(strlen("a")*1024+1);
				char* dir_owner = malloc(strlen("a")*1024+1);
				char* dir_group = malloc(strlen("a")*1024+1);
				printf("123Here5");
				while (fgets(line, sizeof(line), fp1)) 
				{
					
	
					printf("\n line ::: %s\n\n", line); 
					   	
					const char s_m1[2] = " ";
					char *token1_m1;
		
					
					char* duplicate_for_token_path_m1 = malloc(strlen("a")*1024+1);
				
					strcpy(duplicate_for_token_path_m1, line);				

					/* get the first token */
					token1_m1 = strtok(duplicate_for_token_path_m1, s_m1);
						
					int t_counter_m1 = 1;
					while( token1_m1 != NULL)// && t_counter<2) 
				 	{
									
						printf("\nt counter %d token : %s\n",t_counter_m1, token1_m1);
						if(t_counter_m1 == 1)				//file/dir name
							strcpy(dir_name,token1_m1);						
						if(t_counter_m1 == 2)				//owner name
							strcpy(dir_owner,token1_m1);  
						if(t_counter_m1 == 3)				//group name
						{	
							strcpy(dir_group,token1_m1);
							break;  
						}			
						token1_m1 = strtok(NULL, s_m1);		
							  	
						t_counter_m1++;
					

					}
					if(strcmp(token1,dir_name)==0)
					{
						printf("\ndir name %s owner : %s current_user : %s\n",dir_name, dir_owner, current_user);
						printf("\ndir name %s group : %s current_user_group : %s Match? : %d grouplen : %d user_group_len : %d\n",dir_name, dir_group, current_user_group, strcmp(dir_group,current_user_group), (int)strlen(dir_group) , (int)strlen(current_user_group));
						
						char * dir_group_modified = malloc(strlen("a")*1000+1);
						strcpy(dir_group_modified, strip_n_copy(dir_group));
						if(strcmp(dir_owner, current_user)==0)
						{
							perm_granted = 1;
						}
						else if(strcmp(dir_group_modified,current_user_group)==0)
						{
							perm_granted = 1;
						}

					}
		//printf("\n\n\nURGENT TOKEN1 : %s ;DIR_NAME : %s ;DIR_OWNER : %s ;DIR_GROUP : %s\n\n\n",token1,dir_name,dir_owner,dir_group);
				
				}						//end of while read file
				fclose(fp1);
						
					

			


				if(perm_granted == 1)

				{

					strcat(temp_path, "/");
					strcat(temp_path, client_message);
					printf("\ntemp_path : %s\n",temp_path);
					strcat(display_temp_path, "/");
					strcat(display_temp_path, client_message);
				
					strcpy(client_send_message,"$");				//TODO: CHECK IF WE HAVE PERM
					strcat(client_send_message,current_user);			//Building the $username: format
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	  //TOPMOST DIRECTORY RETURN JUST $USERNAME
					strcat(client_send_message,": ");

				}
				else
				{
			
					strcpy(client_send_message,"You do not have the required permissions!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
				}
			








				

			}
			else if(dirExists(verifyDir)==0)
			{	
				printf("Doesnt EXIST\n");
				strcpy(client_send_message,"Directory Does not exist!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");
			}
			else
			{printf("ERROR!!! %d\n",dirExists(verifyDir));
			}
			
		}
		else if(strstr(client_message, "create_dir /simple_slash/simple_home/user") != NULL)		//Absolute
		{
			removeSubstring(client_message, "create_dir ");
			const char s[2] = "/";
			char *token;
			int token_counter = 1;
			char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
			int perm_granted = 0;
			strcpy(duplicate_for_token_path, client_message);				

			/* get the first token */
			token = strtok(duplicate_for_token_path, s);

			/* walk through other tokens */
			while( token != NULL && token_counter!=3) 
		 	{
				printf( "token %s\n", token);    
				token = strtok(NULL, s);				//Count all tokens
				token_counter++;
			}
			
			printf("OBTAINED USER NAME?: %s\n",token);
			if(strcmp(token,current_user)==0)
			{
				perm_granted = 1;
			}


			if(perm_granted == 0)						
			{
				strcpy(client_send_message,"You do not have the required permissions!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");						
			}
			else								//Create directories recursively
			{

				char* new_dirs_path = malloc(strlen("a")*500+1);
				strcpy(new_dirs_path,base_path);
				strcat(new_dirs_path,client_message);
				if(dirExists(new_dirs_path) == 1)
				{
					strcpy(client_send_message,"Directory Already Exists!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
				}
				else
				{
					_mkdir(new_dirs_path,current_user, current_user_group);
					printf("Here8\n");
					strcpy(client_send_message,"Directory Created\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");
				}		
			}
				
				
			
		}
		else if((strstr(client_message, "create_dir") != NULL) &&
		  (((strstr(client_message, "simple_slash") == NULL)&&(strstr(display_temp_path, "simple_slash/simple_home/user") != NULL))
		||(strstr(client_message, "simple_home/user") != NULL) ) )   //Relative
		{
			removeSubstring(client_message, "create_dir ");
			char* new_dirs_path = malloc(strlen("a")*500+1);
			int perm_granted = 0;
			const char s[2] = "/";
			char *token;
			
			strcpy(new_dirs_path,temp_path);
			strcat(new_dirs_path,"/");				
			strcat(new_dirs_path,client_message);
	

			char* duplicate_for_user_name = malloc(strlen("a")*1024+1);

			strcpy(duplicate_for_user_name, new_dirs_path);				

			/* get the first token */
			token = strtok(duplicate_for_user_name, s);
			int token_counter = 1;
			/* walk through other tokens */
			while( token != NULL && token_counter!=7) 
		 	{
				printf( "token %s\n", token);    
				token = strtok(NULL, s);				//Count all tokens
				token_counter++;
			}
			
			printf("OBTAINED USER NAME?: %s\n",token);



			if(strcmp(current_user,token) == 0)			//Perm check
				perm_granted = 1;
		
			printf("DIR PATH : %s perm_granted : %d\n",new_dirs_path, perm_granted);
			
			if(dirExists(new_dirs_path) == 1)
			{
				strcpy(client_send_message,"Directory Already Exists!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");						
			
			}
			else if(perm_granted == 1)
			{
				_mkdir(new_dirs_path,current_user, current_user_group);
			
				strcpy(client_send_message,"Directory Created\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");
			
			}
			else if(perm_granted == 0)
			{	
				printf("\nNO PERMISSIONS!!!\n");
				strcpy(client_send_message,"You do not have the required permissions!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");						

			}
		}
		else if(strstr(client_message, "create_dir") != NULL && (strstr(client_message, "simple_slash") != NULL))  //NOT ALLOWED
		{
			strcpy(client_send_message,"You do not have the required permissions!\n$");				
			strcat(client_send_message,current_user);			
			strcat(client_send_message,": ");
			strcat(client_send_message,display_temp_path);  	  	
			strcat(client_send_message,": ");	
		}
		else if(strstr(client_message, "create_dir") != NULL)
		{
			strcpy(client_send_message,"You do not have the required permissions!\n$");				
			strcat(client_send_message,current_user);			
			strcat(client_send_message,": ");
			strcat(client_send_message,display_temp_path);  	  	
			strcat(client_send_message,": ");	
		
		}
		else if(strstr(client_message, "ls /simple_slash/simple_home") != NULL)
		{
			int perm_granted = 1;			//ASSUMPTION : NO PERMISSSIONS REQD TO ACCESS LS in any directory  however can be changed by adding permission code below
			printf("\nLS ABSOLUTE\n");
			removeSubstring(client_message, "ls ");
			

			int perm_file_exists = 0;

			char* perm_file1 = malloc(strlen("a")*1024+1);
			strcpy(perm_file1, base_path);			
			strcat(perm_file1, client_message);
		 	
			if(dirExists(perm_file1)==0)
			{
				strcpy(client_send_message,"Directory Does not exist!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");
		
			}
			else if(dirExists(perm_file1)==1)
			{
				

				
				
				strcat(perm_file1, "/perm_file.txt");
			

				if(perm_granted == 1)
				{	

					
				
				if( access( perm_file1, F_OK ) != -1 ) 
				{
					perm_file_exists = 1;
					printf("\nPermfile :%s exists!!\n",perm_file1);
				}
				if(perm_file_exists == 0)
				{
					strcpy(client_send_message,"Directory is Empty!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");

				}
				else
				{		
					FILE *fp1 = fopen(perm_file1, "r");


					char line[1001];
					strcpy(client_send_message,"Result of ls :\nDir/File Owner Group\n");				
				
					while (fgets(line, sizeof(line), fp1)) 
					{
				
						printf("\n line ::: %s\n\n", line);
						strcat(client_send_message,line);
				
				
					}
					strcat(client_send_message,"$");
					strcat(client_send_message,current_user);			
						strcat(client_send_message,": ");
						strcat(client_send_message,display_temp_path);  	  	
						strcat(client_send_message,": "); 
					fclose(fp1);
				}
			}
			else if(perm_file_exists == 1)
			{
				strcpy(client_send_message,"You do not have the required permissions!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");	
			}
		}
	}

		else if(strstr(client_message, "ls ") != NULL)
		{
			printf("\nLS RELATIVE\n");
			
			int perm_granted = 1;			//ASSUMPTION : NO PERMISSSIONS REQD TO ACCESS LS in any directory  however can be changed by adding permission code below
			
			removeSubstring(client_message, "ls ");
			

			char* perm_file1 = malloc(strlen("a")*1024+1);
			strcpy(perm_file1, temp_path);
			strcat(perm_file1, "/");			
			strcat(perm_file1, client_message);
		 	
			if(dirExists(perm_file1)==0)
			{
				strcpy(client_send_message,"Directory Does not exist!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");
		
			}
		
			else if(dirExists(perm_file1)==1)
			{
				

				
				
				strcat(perm_file1, "/perm_file.txt");
			
				int perm_file_exists = 0;
				
				if( access( perm_file1, F_OK ) != -1 ) 
				{
					perm_file_exists = 1;
					printf("\nPermfile :%s exists!!\n",perm_file1);
				}
				if(perm_file_exists == 0)
				{
					strcpy(client_send_message,"Directory is Empty!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");

				}
				
				if(perm_granted == 1 && perm_file_exists == 1)
				{			
					FILE *fp1 = fopen(perm_file1, "r");


					char line[1001];
					strcpy(client_send_message,"Result of ls :\nDir/File Owner Group\n");				
				
					while (fgets(line, sizeof(line), fp1)) 
					{
				
						printf("\n line ::: %s\n\n", line);
						strcat(client_send_message,line);
				
				
					}
					strcat(client_send_message,"$");
					strcat(client_send_message,current_user);			
						strcat(client_send_message,": ");
						strcat(client_send_message,display_temp_path);  	  	
						strcat(client_send_message,": "); 
					fclose(fp1);
				}
				else if(perm_granted == 0)
				{
					strcpy(client_send_message,"You do not have the required permissions!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");	
				}
			}
		}
		
		
		else if(strstr(client_message, "fput /simple_slash/simple_home/user") != NULL)		//Absolute
		{
			removeSubstring(client_message, "fput ");
			const char s[2] = "/";
			char *token;
			int token_counter = 1;
			char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
			int perm_granted = 0;
			strcpy(duplicate_for_token_path, client_message);				

			/* get the first token */
			token = strtok(duplicate_for_token_path, s);

			/* walk through other tokens */
			while( token != NULL && token_counter!=3) 
		 	{
				printf( "token %s\n", token);    
				token = strtok(NULL, s);				//Count all tokens
				token_counter++;
			}
			
			printf("OBTAINED USER NAME?: %s\n",token);
			if(strcmp(token,current_user)==0)
			{
				perm_granted = 1;
			}

			


			if(perm_granted == 0)						
			{
				strcpy(client_send_message,"You do not have the required permissions!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");						
			}
			else								//Create directories recursively
			{
				


				
				char cur_dir_path[1024];
				char parent_dir_path[1024];
				
				const char s[2] = "/";
				char *token;
				   
				int token_counter = 0;				//1 (-1)  -> ignore first 				
				
				char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, base_path);				
				strcat(duplicate_for_token_path, client_message);

				/* get the first token */
				token = strtok(duplicate_for_token_path, s);
				   
				/* walk through other tokens */
				while( token != NULL ) 
			 	{
					//printf( "token  %s\n", token);    
					token = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				//printf("token counter %d\n", token_counter);    
				
				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, base_path);				
				strcat(duplicate_for_token_path, client_message);  	
				
				token = strtok(duplicate_for_token_path, s);
								
				int temp_counter = 1;
				strcat(cur_dir_path, "/");
				
				strcat(cur_dir_path, token);
				
				while( token != NULL) 
			 	{
					if(temp_counter>=(token_counter-1))
					{
						token = strtok(NULL, s);
						break;			
					}					
					token = strtok(NULL, s);		
	//				printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
					strcat(cur_dir_path, "/");					
					strcat(cur_dir_path, token);
					temp_counter++;
					

				}
				char* cur_file_name = malloc(strlen("a")*1000+1);
				strcpy(cur_file_name, token);
				
				

				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, base_path);				
				strcat(duplicate_for_token_path, client_message);  	
				
				token = strtok(duplicate_for_token_path, s);
								
				int temp_counter_2 = 1;
				strcat(parent_dir_path, "/");
				
				strcat(parent_dir_path, token);
				
				while( token != NULL) 
			 	{
					if(temp_counter_2>=(token_counter-2))
					{
						token = strtok(NULL, s);
						break;			
					}					
					token = strtok(NULL, s);		
	//				printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
					strcat(parent_dir_path, "/");					
					strcat(parent_dir_path, token);
					temp_counter_2++;
					

				}
				char* cur_dir_name = malloc(strlen("a")*1000+1);
				strcpy(cur_dir_name, token);

				printf("cur dir path :%s \nparent dir path : %s\n cur dir name : %s\n cur file name : %s\n", cur_dir_path, parent_dir_path, cur_dir_name, cur_file_name);    	


				printf("cur dir path :%sexists? : %d\n", cur_dir_path, dirExists(cur_dir_path));    	
				char *temp_cur_dir_path = strip_n_copy(cur_dir_path);




				if(dirExists(cur_dir_path) == 1 || dirExists(temp_cur_dir_path) == 1)
				{
					FILE *fp;
					char* final_file_path = malloc(sizeof("a")*1000+1); 
					strcpy(final_file_path, cur_dir_path);
					strcat(final_file_path, "/");
					strcat(final_file_path, cur_file_name);
					fp = fopen(final_file_path, "a");				// ENTER TEXT TO FILE
				   	strcpy(client_send_message,"Enter text to write to File : \n");				
				
					int write_size = strlen(client_send_message);	
					write(sock , client_send_message , strlen(client_send_message));
					memset(client_send_message, 0, write_size);
					
					char* temp_server_reply = malloc(sizeof("a")*1000+1); 
					int read_size_temp =  recv(sock , temp_server_reply , 2000 , 0);
					if(read_size_temp < 0)
					{
					    puts("recv failed");
					    break;
					}
					temp_server_reply[read_size_temp] = '\0';
					char* data_to_write = malloc(strlen(temp_server_reply)+1);
					strcpy(data_to_write,temp_server_reply);
					printf("\nDATA TO WRITE : %s\n",data_to_write);
				   fprintf(fp, "%s\n",data_to_write);		
				
				   //fputs("parent \n", fp);
				   fclose(fp);



				

					FILE *fp1;
					char* final_file_path1 = malloc(sizeof("a")*1000+1); 
					strcpy(final_file_path1, cur_dir_path);
					strcat(final_file_path1, "/perm_file.txt");
					//strcat(final_file_path, cur_file_name);
					fp1 = fopen(final_file_path1, "a");				// ENTER TEXT TO FILE
				   	
					
					fprintf(fp1, "%s %s %s\n",cur_file_name, current_user, current_user_group);		
  				
				   //fputs("parent \n", fp);
				   fclose(fp1);





					
					printf("Create file(s) Here8\n");
					strcpy(client_send_message,"File Created\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");
						
			
				}
				else
				{	
					strcpy(client_send_message,"Directory Doesn't Exists!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
					
				}		
			}
				
				
			
		}
			



		else if(   (strstr(client_message, "fput ") != NULL)
				&&((strstr(client_message, "simple_slash") == NULL&&strstr(temp_path, "simple_slash/simple_home/user") != NULL)
				||(strstr(client_message, "simple_home/user") != NULL&&strcmp(display_temp_path, "/simple_slash") == 0)
				||(strstr(client_message, "user") != NULL&&strcmp(display_temp_path, "/simple_slash/simple_home") == 0)
				)
			
			)		

												//Relative
		{
			removeSubstring(client_message, "fput ");
			const char s[2] = "/";
			char *token;
			int token_counter = 1;
			char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
			int perm_granted = 0;
			strcpy(duplicate_for_token_path, temp_path);				
			strcat(duplicate_for_token_path, "/");				
			strcat(duplicate_for_token_path, client_message);				

			/* get the first token */
			token = strtok(duplicate_for_token_path, s);

			/* walk through other tokens */
			while( token != NULL && token_counter!=7) 
		 	{
				printf( "token %s\n", token);    
				token = strtok(NULL, s);				//Count all tokens
				token_counter++;
			}
			
			printf("OBTAINED USER NAME?: %s\n",token);
			if(strcmp(token,current_user)==0)
			{
				perm_granted = 1;
			}

			


			if(perm_granted == 0)						
			{
				strcpy(client_send_message,"You do not have the required permissions!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");						
			}
			else								//Create directories recursively
			{
				


				
				char cur_dir_path[1024];
				char parent_dir_path[1024];
				
				const char s[2] = "/";
				char *token;
				   
				int token_counter = 0;				//1 (-1)  -> ignore first 				
				
				char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, temp_path);				
				strcat(duplicate_for_token_path, "/");
				strcat(duplicate_for_token_path, client_message);

				/* get the first token */
				token = strtok(duplicate_for_token_path, s);
				   
				/* walk through other tokens */
				while( token != NULL ) 
			 	{
					//printf( "token  %s\n", token);    
					token = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				//printf("token counter %d\n", token_counter);    
				
				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, temp_path);				
				strcat(duplicate_for_token_path, "/");
				strcat(duplicate_for_token_path, client_message);

				token = strtok(duplicate_for_token_path, s);
								
				int temp_counter = 1;
				strcpy(cur_dir_path, "/");
				
				strcat(cur_dir_path, token);
				
				while( token != NULL) 
			 	{
					if(temp_counter>=(token_counter-1))
					{
						token = strtok(NULL, s);
						break;			
					}					
					token = strtok(NULL, s);		
					printf("cur_dir Path :%s\n",cur_dir_path);    	
					strcat(cur_dir_path, "/");					
					strcat(cur_dir_path, token);
					temp_counter++;
					

				}
				char* cur_file_name = malloc(strlen("a")*1000+1);
				strcpy(cur_file_name, token);
				
				

				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, temp_path);				
				strcat(duplicate_for_token_path, "/");
				strcat(duplicate_for_token_path, client_message);
  	
				
				token = strtok(duplicate_for_token_path, s);
								
				int temp_counter_2 = 1;
				strcat(parent_dir_path, "/");
				
				strcat(parent_dir_path, token);
				
				while( token != NULL) 
			 	{
					if(temp_counter_2>=(token_counter-2))
					{
						token = strtok(NULL, s);
						break;			
					}					
					token = strtok(NULL, s);		
	//				printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
					strcat(parent_dir_path, "/");					
					strcat(parent_dir_path, token);
					temp_counter_2++;
					

				}
				char* cur_dir_name = malloc(strlen("a")*1000+1);
				strcpy(cur_dir_name, token);

				printf("cur dir path :%s \nparent dir path : %s\n cur dir name : %s\n cur file name : %s\n", cur_dir_path, parent_dir_path, cur_dir_name, cur_file_name);    	


				printf("cur dir path :%sexists? : %d\n", cur_dir_path, dirExists(cur_dir_path));    	
				char *temp_cur_dir_path = strip_n_copy(cur_dir_path);




				if(dirExists(cur_dir_path) == 1 || dirExists(temp_cur_dir_path) == 1)
				{
					FILE *fp;
					char* final_file_path = malloc(sizeof("a")*1000+1); 
					strcpy(final_file_path, cur_dir_path);
					strcat(final_file_path, "/");
					strcat(final_file_path, cur_file_name);
					fp = fopen(final_file_path, "a");				// ENTER TEXT TO FILE
				   	strcpy(client_send_message,"Enter text to write to File : \n");				
				
					int write_size = strlen(client_send_message);	
					write(sock , client_send_message , strlen(client_send_message));
					memset(client_send_message, 0, write_size);
					
					char* temp_server_reply = malloc(sizeof("a")*1000+1); 
					int read_size_temp =  recv(sock , temp_server_reply , 2000 , 0);
					if(read_size_temp < 0)
					{
					    puts("recv failed");
					    break;
					}
					temp_server_reply[read_size_temp] = '\0';
					char* data_to_write = malloc(strlen(temp_server_reply)+1);
					strcpy(data_to_write,temp_server_reply);
					printf("\nDATA TO WRITE : %s\n",data_to_write);
				   fprintf(fp, "%s\n",data_to_write);		
				
				   //fputs("parent \n", fp);
				   fclose(fp);



				

					FILE *fp1;
					char* final_file_path1 = malloc(sizeof("a")*1000+1); 
					strcpy(final_file_path1, cur_dir_path);
					strcat(final_file_path1, "/perm_file.txt");
					//strcat(final_file_path, cur_file_name);
					fp1 = fopen(final_file_path1, "a");				// ENTER TEXT TO FILE
				   	
					
					fprintf(fp1, "%s %s %s\n",cur_file_name, current_user, current_user_group);		
  				
				   //fputs("parent \n", fp);
				   fclose(fp1);





					
					printf("Create file(s) Here8\n");
					strcpy(client_send_message,"File Created\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");
						
			
				}
				else
				{	
					strcpy(client_send_message,"Directory Doesn't Exists!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
					
				}		
			}
				
				
			
		}


		


		
		else if(strstr(client_message, "fget /simple_slash/simple_home/user") != NULL)		//Absolute
		{
			removeSubstring(client_message, "fget ");
			const char s[2] = "/";
			char *token;
			int token_counter = 1;
			char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
			int perm_granted = 0;


			
			strcpy(duplicate_for_token_path, base_path);				
			strcat(duplicate_for_token_path, client_message);				

			/* get the first token */
			token = strtok(duplicate_for_token_path, s);

			/* walk through other tokens */
			while( token != NULL && token_counter!=7) 
		 	{
				printf( "token %s\n", token);    
				token = strtok(NULL, s);				//Count all tokens
				token_counter++;
			}
			
			printf("OBTAINED USER NAME?: %s\n",token);
			if(strcmp(token,current_user)==0)
			{
				perm_granted = 1;
			}

			char* verifyDir = malloc(strlen("a")*2000+1);
			duplicate_for_token_path = NULL;
			duplicate_for_token_path = malloc(strlen("a")*1024+1);
			printf("\nSuperUSER1\n");	
			
			strcpy(duplicate_for_token_path, base_path);				
			strcat(duplicate_for_token_path, client_message);			
			printf("\nMAIN PATH TO USED FOR VERIFY : %s\n",duplicate_for_token_path);	
			
	token_counter = 1;				

		/* get the first token */
				token = strtok(duplicate_for_token_path, s);
			printf("\nSuperUSER3\n");		   
					/* walk through other tokens */
				while( token != NULL ) 
			 	{
					printf( "token  %s counter : %d\n", token,token_counter);    
					token = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				token_counter--;
					//printf("token counter %d\n", token_counter);    
				printf("\nSuperUSER4\n");
				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
			strcpy(duplicate_for_token_path, base_path);				
			strcat(duplicate_for_token_path, client_message);			
			printf("\nMAIN PATH TO USED FOR VERIFY : %s\n",duplicate_for_token_path);	
				
				
				token = strtok(duplicate_for_token_path, s);
				printf("\nSuperUSER5\n");				
				int temp_counter = 1;
				strcat(verifyDir, "/");
				
				strcat(verifyDir, token);
				
				while( token != NULL) 
			 	{
					if(temp_counter>=(token_counter-1))
					{
						token = strtok(NULL, s);
						break;			
					}					
					token = strtok(NULL, s);		
					printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
					strcat(verifyDir, "/");					
					strcat(verifyDir, token);
					temp_counter++;
					printf("verify : %s;token : %s\n",verifyDir, token);    	
				
					

				}
					
				printf("\nSuperUSER6\n");





			if(dirExists(verifyDir)==0)
			{
				printf("\n\n\nERROR DIR DOESNT EXIST\n\n\n");
				strcpy(client_send_message,"Directory Does not exist!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");
			}	
			
			else if(dirExists(verifyDir)==1 && perm_granted == 0)			
			{	
				
				
				
				printf("\nSuperUSER7\n");

				
				
				char path_builder[1024];
				
				const char s[2] = "/";
				char *token1;
				   
				int token_counter = 0;				//1 (-1)  -> ignore first 				
				
				char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, verifyDir);				

				/* get the first token */
				token1 = strtok(duplicate_for_token_path, s);
				   
				/* walk through other tokens */
				while( token1 != NULL ) 
			 	{
					//printf( "token1 : %s\n", token1);    
					token1 = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				//printf("token counter %d\n", token_counter);    
				//printf( "tmp :  %s\n",tmp); 

				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				strcpy(duplicate_for_token_path, verifyDir);				
				  	
				
				token1 = strtok(duplicate_for_token_path, s);
								
				int temp_counter = 1;
				strcpy(path_builder,"/");					//Building path except the last token
				
				strcat(path_builder, token1);
				
				while( token1 != NULL) 
			 	{
					if(temp_counter>=(token_counter-1))
					{
						token1 = strtok(NULL, s);
						break;			
					}
					token1 = strtok(NULL, s);		
				//	printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token1);    				
					strcat(path_builder, "/");					
					strcat(path_builder, token1);
					temp_counter++;
					

				}
	

				char* perm_file1 = malloc(strlen("a")*1024+1);
				strcpy(perm_file1, path_builder);
			 	strcat(perm_file1, "/perm_file.txt");
				FILE *fp1 = fopen(perm_file1, "r");



				

				char line[256];
				char* dir_name = malloc(strlen("a")*1024+1);
				char* dir_owner = malloc(strlen("a")*1024+1);
				char* dir_group = malloc(strlen("a")*1024+1);

				while (fgets(line, sizeof(line), fp1)) 
				{
					
	
					printf("\n line ::: %s\n\n", line); 
					   	
					const char s_m1[2] = " ";
					char *token1_m1;
		
					
					char* duplicate_for_token_path_m1 = malloc(strlen("a")*1024+1);
				
					strcpy(duplicate_for_token_path_m1, line);				

					/* get the first token */
					token1_m1 = strtok(duplicate_for_token_path_m1, s_m1);
						
					int t_counter_m1 = 1;
					while( token1_m1 != NULL)// && t_counter<2) 
				 	{
									
						printf("\nt counter %d token : %s\n",t_counter_m1, token1_m1);
						if(t_counter_m1 == 1)				//file/dir name
							strcpy(dir_name,token1_m1);						
						if(t_counter_m1 == 2)				//owner name
							strcpy(dir_owner,token1_m1);  
						if(t_counter_m1 == 3)				//group name
						{	
							strcpy(dir_group,token1_m1);
							break;  
						}			
						token1_m1 = strtok(NULL, s_m1);		
							  	
						t_counter_m1++;
					

					}
					if(strcmp(token1,dir_name)==0)
					{
						printf("\ndir name %s owner : %s current_user : %s\n",dir_name, dir_owner, current_user);
						printf("\ndir name %s group : %s current_user_group : %s Match? : %d grouplen : %d user_group_len : %d\n",dir_name, dir_group, current_user_group, strcmp(dir_group,current_user_group), (int)strlen(dir_group) , (int)strlen(current_user_group));
						
						char * dir_group_modified = malloc(strlen("a")*1000+1);
						strcpy(dir_group_modified, strip_n_copy(dir_group));
						if(strcmp(dir_owner, current_user)==0)
						{
							perm_granted = 1;
						}
						else if(strcmp(dir_group_modified,current_user_group)==0)
						{
							perm_granted = 1;
						}

					}
		//printf("\n\n\nURGENT TOKEN1 : %s ;DIR_NAME : %s ;DIR_OWNER : %s ;DIR_GROUP : %s\n\n\n",token1,dir_name,dir_owner,dir_group);
				
				}						//end of while read file
	
						
					

			


				if(perm_granted == 1)

				{


					


					
					char cur_dir_path[1024];
					char parent_dir_path[1024];
				
					const char s[2] = "/";
					char *token;
					   
					int token_counter = 0;				//1 (-1)  -> ignore first 				
				
					char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
					strcpy(duplicate_for_token_path, base_path);				
					strcat(duplicate_for_token_path, client_message);				

					/* get the first token */
					token = strtok(duplicate_for_token_path, s);
					   
					/* walk through other tokens */
					while( token != NULL ) 
				 	{
						//printf( "token  %s\n", token);    
						token = strtok(NULL, s);				//Count all tokens
						token_counter++;
					}
					//printf("token counter %d\n", token_counter);    
				
					duplicate_for_token_path = NULL;
					duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
					strcpy(duplicate_for_token_path, base_path);				
					strcat(duplicate_for_token_path, client_message);				

					token = strtok(duplicate_for_token_path, s);
								
					int temp_counter = 1;
					strcat(cur_dir_path, "/");
				
					strcat(cur_dir_path, token);
				
					while( token != NULL) 
				 	{
						if(temp_counter>=(token_counter-1))
						{
							token = strtok(NULL, s);
							break;			
						}					
						token = strtok(NULL, s);		
		//				printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
						strcat(cur_dir_path, "/");					
						strcat(cur_dir_path, token);
						temp_counter++;
					

					}
					char* cur_file_name = malloc(strlen("a")*1000+1);
					strcpy(cur_file_name, token);
				
				

					duplicate_for_token_path = NULL;
					duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
					strcpy(duplicate_for_token_path, base_path);				
					strcat(duplicate_for_token_path, client_message);				
	
				
					token = strtok(duplicate_for_token_path, s);
								
					int temp_counter_2 = 1;
					strcat(parent_dir_path, "/");
				
					strcat(parent_dir_path, token);
				
					while( token != NULL) 
				 	{
						if(temp_counter_2>=(token_counter-2))
						{
							token = strtok(NULL, s);
							break;			
						}					
						token = strtok(NULL, s);		
		//				printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
						strcat(parent_dir_path, "/");					
						strcat(parent_dir_path, token);
						temp_counter_2++;
					

					}
					char* cur_dir_name = malloc(strlen("a")*1000+1);
					strcpy(cur_dir_name, token);

					printf("cur dir path :%s \nparent dir path : %s\n cur dir name : %s\n cur file name : %s\n", cur_dir_path, parent_dir_path, cur_dir_name, cur_file_name);    	


					printf("cur dir path :%sexists? : %d\n", cur_dir_path, dirExists(cur_dir_path));    	
					char *temp_cur_dir_path = strip_n_copy(cur_dir_path);




					if(dirExists(cur_dir_path) == 1 || dirExists(temp_cur_dir_path) == 1)
					{	
						printf("\nREADY TO READ DATA\n");
						FILE *fp;
						char* final_file_path = malloc(sizeof("a")*1000+1); 
						strcpy(final_file_path, cur_dir_path);
						strcat(final_file_path, "/");
						strcat(final_file_path, cur_file_name);
						fp = fopen(final_file_path, "r");				//TODO: READ TEXT FROM FILE
					   	char * read_data;
						fseek(fp, 0, SEEK_END); 
						long size = ftell(fp);
						fseek(fp, 0, SEEK_SET);
						read_data = malloc(size);
						fread(read_data, 1, size, fp);
					   	printf("\nRead Data : %s\n",read_data);		
				
					   	fclose(fp);



	




					
						printf("\nHere8\n");
						strcpy(client_send_message,"Read Data:\n");
						strcat(client_send_message,read_data);				
						strcat(client_send_message,"\n$");
						strcat(client_send_message,current_user);			
						strcat(client_send_message,": ");
						strcat(client_send_message,display_temp_path);  	  	
						strcat(client_send_message,": ");
						
			
				}
				else
				{	
					strcpy(client_send_message,"Directory Doesn't Exists!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
					
				}










				}
				else
				{
			
					strcpy(client_send_message,"You do not have the required permissions!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
				}
				
			}
			else if(perm_granted == 1)
			{
			
				printf("\nREADY TO READ DATA\n");
						FILE *fp;
						char* final_file_path = malloc(sizeof("a")*1000+1); 
						
						strcpy(final_file_path, base_path);				
						strcat(final_file_path, client_message);  	
				
						fp = fopen(final_file_path, "r");				//TODO: READ TEXT FROM FILE
					   	char * read_data;
						fseek(fp, 0, SEEK_END); 
						long size = ftell(fp);
						fseek(fp, 0, SEEK_SET);
						read_data = malloc(size);
						fread(read_data, 1, size, fp);
					   	printf("\nRead Data : %s\n",read_data);		
				
					   	fclose(fp);


					
						printf("\nHere8\n");
						strcpy(client_send_message,"Read Data:\n");
						strcat(client_send_message,read_data);				
						strcat(client_send_message,"\n$");
						strcat(client_send_message,current_user);			
						strcat(client_send_message,": ");
						strcat(client_send_message,display_temp_path);  	  	
						strcat(client_send_message,": ");
						
									
			
			}
			else if(perm_granted == 0)
			{
					strcpy(client_send_message,"You do not have the required permissions!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
			}


		
				
			
		}



		else if(   (strstr(client_message, "fget ") != NULL)
				&&((strstr(client_message, "simple_slash") == NULL&&strstr(temp_path, "simple_slash/simple_home/user") != NULL)
				||(strstr(client_message, "simple_home/user") != NULL&&strcmp(display_temp_path, "/simple_slash") == 0)
				||(strstr(client_message, "user") != NULL&&strcmp(display_temp_path, "/simple_slash/simple_home") == 0)
				)
			
			)		

												//Relative
		{
			removeSubstring(client_message, "fget ");
			const char s[2] = "/";
			char *token;
			int token_counter = 1;
			char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
			int perm_granted = 0;
			strcpy(duplicate_for_token_path, temp_path);
			strcat(duplicate_for_token_path, "/");				
			strcat(duplicate_for_token_path, client_message);				

			/* get the first token */
			token = strtok(duplicate_for_token_path, s);

			/* walk through other tokens */
			while( token != NULL && token_counter!=7) 
		 	{
				printf( "token %s\n", token);    
				token = strtok(NULL, s);				//Count all tokens
				token_counter++;
			}
			
			printf("OBTAINED USER NAME?: %s\n",token);
			if(strcmp(token,current_user)==0)
			{
				perm_granted = 1;
			}

			char* verifyDir = malloc(strlen("a")*2000+1);
			duplicate_for_token_path = NULL;
			duplicate_for_token_path = malloc(strlen("a")*1024+1);
			printf("\nSuperUSER1\n");
				token_counter = 1;	
				strcpy(duplicate_for_token_path, temp_path);				
				strcat(duplicate_for_token_path, "/");  	
				strcat(duplicate_for_token_path, client_message);
					/* get the first token */
				token = strtok(duplicate_for_token_path, s);
			printf("\nSuperUSER3\n");		   
					/* walk through other tokens */
				while( token != NULL ) 
			 	{
						//printf( "token  %s\n", token);    
					token = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
					token_counter--;
					//printf("token counter %d\n", token_counter);    
				printf("\nSuperUSER4\n");
				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, temp_path);				
				strcat(duplicate_for_token_path, "/");  	
				strcat(duplicate_for_token_path, client_message);  	
				
				token = strtok(duplicate_for_token_path, s);
				printf("\nSuperUSER5\n");				
				int temp_counter = 1;
				strcat(verifyDir, "/");
				
				strcat(verifyDir, token);
				
				while( token != NULL && temp_counter!=8) 
			 	{
					if(temp_counter==6)
					{
						token = strtok(NULL, s);
						strcat(verifyDir, "/");					
						strcat(verifyDir, token);
						break;			
					}					
					token = strtok(NULL, s);		
					printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
					strcat(verifyDir, "/");					
					strcat(verifyDir, token);
					temp_counter++;
					printf("verify : %s;token : %s\n",verifyDir, token);    	
				
					

				}
					
				printf("\nSuperUSER6\n verifyDir : %s, exists:%d",verifyDir,dirExists(verifyDir));





			if(dirExists(verifyDir)==0)
			{
				printf("\n\n\nERROR DIR DOESNT EXIST\n\n\n");
				strcpy(client_send_message,"Directory Does not exist!\n$");				
				strcat(client_send_message,current_user);			
				strcat(client_send_message,": ");
				strcat(client_send_message,display_temp_path);  	  	
				strcat(client_send_message,": ");
			}	
			
			else if(dirExists(verifyDir)==1 && perm_granted == 0)			
			{	
				
				
				
				printf("\nSuperUSER7\n");

				
				
				char path_builder[1024];
				
				const char s[2] = "/";
				char *token1;
				   
				int token_counter = 0;				//1 (-1)  -> ignore first 				
				
				char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
				strcpy(duplicate_for_token_path, verifyDir);				

				/* get the first token */
				token1 = strtok(duplicate_for_token_path, s);
				   
				/* walk through other tokens */
				while( token1 != NULL ) 
			 	{
					//printf( "token1 : %s\n", token1);    
					token1 = strtok(NULL, s);				//Count all tokens
					token_counter++;
				}
				//printf("token counter %d\n", token_counter);    
				//printf( "tmp :  %s\n",tmp); 

				duplicate_for_token_path = NULL;
				duplicate_for_token_path = malloc(strlen("a")*1024+1);
				strcpy(duplicate_for_token_path, verifyDir);				
				  	
				
				token1 = strtok(duplicate_for_token_path, s);
								
				int temp_counter = 1;
				strcpy(path_builder,"/");					//Building path except the last token
				
				strcat(path_builder, token1);
				
				while( token1 != NULL) 
			 	{
					if(temp_counter>=(token_counter-1))
					{
						token1 = strtok(NULL, s);
						break;			
					}
					token1 = strtok(NULL, s);		
				//	printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token1);    				
					strcat(path_builder, "/");					
					strcat(path_builder, token1);
					temp_counter++;
					

				}
	

				char* perm_file1 = malloc(strlen("a")*1024+1);
				strcpy(perm_file1, path_builder);
			 	strcat(perm_file1, "/perm_file.txt");
				FILE *fp1 = fopen(perm_file1, "r");



				

				char line[256];
				char* dir_name = malloc(strlen("a")*1024+1);
				char* dir_owner = malloc(strlen("a")*1024+1);
				char* dir_group = malloc(strlen("a")*1024+1);

				while (fgets(line, sizeof(line), fp1)) 
				{
					
	
					printf("\n line ::: %s\n\n", line); 
					   	
					const char s_m1[2] = " ";
					char *token1_m1;
		
					
					char* duplicate_for_token_path_m1 = malloc(strlen("a")*1024+1);
				
					strcpy(duplicate_for_token_path_m1, line);				

					/* get the first token */
					token1_m1 = strtok(duplicate_for_token_path_m1, s_m1);
						
					int t_counter_m1 = 1;
					while( token1_m1 != NULL)// && t_counter<2) 
				 	{
									
						printf("\nt counter %d token : %s\n",t_counter_m1, token1_m1);
						if(t_counter_m1 == 1)				//file/dir name
							strcpy(dir_name,token1_m1);						
						if(t_counter_m1 == 2)				//owner name
							strcpy(dir_owner,token1_m1);  
						if(t_counter_m1 == 3)				//group name
						{	
							strcpy(dir_group,token1_m1);
							break;  
						}			
						token1_m1 = strtok(NULL, s_m1);		
							  	
						t_counter_m1++;
					

					}
					if(strcmp(token1,dir_name)==0)
					{
						printf("\ndir name %s owner : %s current_user : %s\n",dir_name, dir_owner, current_user);
						printf("\ndir name %s group : %s current_user_group : %s Match? : %d grouplen : %d user_group_len : %d\n",dir_name, dir_group, current_user_group, strcmp(dir_group,current_user_group), (int)strlen(dir_group) , (int)strlen(current_user_group));
						
						char * dir_group_modified = malloc(strlen("a")*1000+1);
						strcpy(dir_group_modified, strip_n_copy(dir_group));
						if(strcmp(dir_owner, current_user)==0)
						{
							perm_granted = 1;
						}
						else if(strcmp(dir_group_modified,current_user_group)==0)
						{
							perm_granted = 1;
						}

					}
		//printf("\n\n\nURGENT TOKEN1 : %s ;DIR_NAME : %s ;DIR_OWNER : %s ;DIR_GROUP : %s\n\n\n",token1,dir_name,dir_owner,dir_group);
				
				}						//end of while read file
	
						
					

			


				if(perm_granted == 1)

				{


					


					
					
					char parent_dir_path[1024];
				
					const char s[2] = "/";
					char *token;
					   
					int token_counter = 0;				//1 (-1)  -> ignore first 				
				
					char* duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
					strcpy(duplicate_for_token_path, temp_path);				
					strcat(duplicate_for_token_path, "/");
					strcat(duplicate_for_token_path, client_message);

					/* get the first token */
					token = strtok(duplicate_for_token_path, s);
					   
					/* walk through other tokens */
					while( token != NULL ) 
				 	{
						//printf( "token  %s\n", token);    
						token = strtok(NULL, s);				//Count all tokens
						token_counter++;
					}
					//printf("token counter %d\n", token_counter);    
				
					duplicate_for_token_path = NULL;
					duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
					
					strcpy(duplicate_for_token_path, temp_path);				
					strcat(duplicate_for_token_path, "/");
					strcat(duplicate_for_token_path, client_message);

					token = strtok(duplicate_for_token_path, s);
					char cur_dir_path[1024];		
					int temp_counter = 1;
					strcpy(cur_dir_path, "/");
				
					strcat(cur_dir_path, token);
					printf("\nCur dir path mew2 :%s\n",cur_dir_path);
					while( token != NULL) 
				 	{
						if(temp_counter>=(token_counter-1))
						{
							token = strtok(NULL, s);
							break;			
						}					
						token = strtok(NULL, s);		
		//				printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
						strcat(cur_dir_path, "/");					
						strcat(cur_dir_path, token);
						printf("\nCur dir path mew2 :%s\n",cur_dir_path);
						temp_counter++;
					

					}
					char* cur_file_name = malloc(strlen("a")*1000+1);
					strcpy(cur_file_name, token);
				
					printf("\nCur dir path mew2 :%s\n",cur_dir_path);

					duplicate_for_token_path = NULL;
					duplicate_for_token_path = malloc(strlen("a")*1024+1);
				
					
					strcpy(duplicate_for_token_path, temp_path);				
					strcat(duplicate_for_token_path, "/");
					strcat(duplicate_for_token_path, client_message);

					token = strtok(duplicate_for_token_path, s);
								
					int temp_counter_2 = 1;
					strcat(parent_dir_path, "/");
				
					strcat(parent_dir_path, token);
				
					while( token != NULL) 
				 	{
						if(temp_counter_2>=(token_counter-2))
						{
							token = strtok(NULL, s);
							break;			
						}					
						token = strtok(NULL, s);		
		//				printf("temp counter %d token counter %d  token : %s\n",temp_counter, token_counter, token);    	
						strcat(parent_dir_path, "/");					
						strcat(parent_dir_path, token);
						temp_counter_2++;
					

					}
					char* cur_dir_name = malloc(strlen("a")*1000+1);
					strcpy(cur_dir_name, token);

					printf("cur dir path :%s \nparent dir path : %s\n cur dir name : %s\n cur file name : %s\n", cur_dir_path, parent_dir_path, cur_dir_name, cur_file_name);    	


					printf("cur dir path :%sexists? : %d\n", cur_dir_path, dirExists(cur_dir_path));    	
					char *temp_cur_dir_path = strip_n_copy(cur_dir_path);




					if(dirExists(cur_dir_path) == 1 || dirExists(temp_cur_dir_path) == 1)
					{	
						printf("\nREADY TO READ DATA\n");
						FILE *fp;
						char* final_file_path = malloc(sizeof("a")*1000+1); 
						strcpy(final_file_path, cur_dir_path);
						strcat(final_file_path, "/");
						strcat(final_file_path, cur_file_name);
						fp = fopen(final_file_path, "r");				//TODO: READ TEXT FROM FILE
					   	char * read_data;
						fseek(fp, 0, SEEK_END); 
						long size = ftell(fp);
						fseek(fp, 0, SEEK_SET);
						read_data = malloc(size);
						fread(read_data, 1, size, fp);
					   	printf("\nRead Data : %s\n",read_data);		
				
					   	fclose(fp);



	




					
						printf("\nHere8\n");
						strcpy(client_send_message,"Read Data:\n");
						strcat(client_send_message,read_data);				
						strcat(client_send_message,"\n$");
						strcat(client_send_message,current_user);			
						strcat(client_send_message,": ");
						strcat(client_send_message,display_temp_path);  	  	
						strcat(client_send_message,": ");
						
			
				}
				else
				{	
					strcpy(client_send_message,"Directory Doesn't Exists!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
					
				}










				}
				else
				{
			
					strcpy(client_send_message,"You do not have the required permissions!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
				}
				
			}
			else if(perm_granted == 1)
			{
			
				printf("\nREADY TO READ DATA\n");
						FILE *fp;
						char* final_file_path = malloc(sizeof("a")*1000+1); 
						printf("\nMain_user1\n");
						strcpy(final_file_path, temp_path);				
						strcat(final_file_path, "/");
						strcat(final_file_path, client_message);  	
				
						fp = fopen(final_file_path, "r");				//TODO: READ TEXT FROM FILE
					   	char * read_data;
						fseek(fp, 0, SEEK_END); 
						long size = ftell(fp);
						fseek(fp, 0, SEEK_SET);
						read_data = malloc(size);
						fread(read_data, 1, size, fp);
					   	printf("\nRead Data : %s\n",read_data);		
				
					   	fclose(fp);


					
						printf("\nHere8\n");
						strcpy(client_send_message,"Read Data:\n");
						strcat(client_send_message,read_data);				
						strcat(client_send_message,"\n$");
						strcat(client_send_message,current_user);			
						strcat(client_send_message,": ");
						strcat(client_send_message,display_temp_path);  	  	
						strcat(client_send_message,": ");
						
									
			
			}
			else if(perm_granted == 0)
			{
					strcpy(client_send_message,"You do not have the required permissions!\n$");				
					strcat(client_send_message,current_user);			
					strcat(client_send_message,": ");
					strcat(client_send_message,display_temp_path);  	  	
					strcat(client_send_message,": ");						
			
			}










		
				
				
			
		}



		



		else									//INVALID COMMAND
		{
		char* newstr = strip_n_copy(display_temp_path);
		printf("STRCMP : %d  display_temp_path : %s %d\n",strcmp(display_temp_path, "/simple_slash"),display_temp_path,(int)strlen(display_temp_path));
		printf("STRCMP : %d display_temp_path : %s %d\n",strcmp(newstr, "/simple_slash"),display_temp_path,(int)strlen(newstr));
				
		strcpy(client_send_message,"Invalid Command!\n$");				
			strcat(client_send_message,current_user);			
			strcat(client_send_message,": ");
			strcat(client_send_message,display_temp_path);  	  	
			strcat(client_send_message,": ");	
											
		}



		printf("Sending the following to the client : %s\n",client_send_message);
				
		int write_size = strlen(client_send_message);	
		write(sock , client_send_message , strlen(client_send_message));
		memset(client_send_message, 0, write_size);
		


	}					//end of logged_in ==1
	

    }
     
    if(read_size == 0)
    {
        int i;
	int log_out = 0, log_out_pos = -1;

	for(i = 0; i <= logged_in_counter; ++i)
	{	
		//printf("logged_in_users[i]:%s---client_message:%s---strcmp:%d\n",logged_in_users[i],client_message,strcmp	(logged_in_users[i], client_message));
  			
    		if(!strcmp(logged_in_users[i], current_user))
    		{
			log_out = 1;         		
			log_out_pos = i;
    		}
	}
	if(log_out == 1)
	{	
		for(i = log_out_pos; i < logged_in_counter; ++i)
		{	
   			strcpy(logged_in_users[i], logged_in_users[i+1]);
	    	}
		strcpy(logged_in_users[logged_in_counter], "");
		logged_in_counter--;
	}

	puts("Client disconnected");
	
	printf("No. of current logged in users : %d\n",logged_in_counter);

        fflush(stdout);
 	
       
    }
    else if(read_size == -1)
    {
        perror("recv failed");
    }
         
    //Free the socket pointer
    free(socket_desc);
     
    return 0;
}
